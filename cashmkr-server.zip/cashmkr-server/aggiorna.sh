#!/bin/bash
# Aggiornamento: bash aggiorna.sh INDIRIZZO_DEL_FILE_ZIP   (i dati in data/ restano)
set -e
cd "$(dirname "$0")"; DIR="$(pwd)"
[ -z "$1" ] && { echo "Uso: bash aggiorna.sh https://.../cashmkr-server.zip"; exit 1; }
TMP=$(mktemp -d); curl -fsSL "$1" -o "$TMP/s.zip"; unzip -q "$TMP/s.zip" -d "$TMP"
cp -r "$TMP"/cashmkr-server/{server.js,lib,vendor,installa.sh,aggiorna.sh,LEGGIMI-SERVER.txt} "$DIR"/ 2>/dev/null || true
rm -rf "$TMP"; sudo systemctl restart cashmkr; echo "Aggiornato e riavviato. I conti e le impostazioni sono rimasti."
