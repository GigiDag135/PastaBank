#!/bin/bash
# Rende il server raggiungibile in https (sola lettura) per il teletrasporto dell'app.
# Prima: nome creato su duckdns.org e porte 80 e 443 aperte nella Security List di Oracle.
set -e
cd "$(dirname "$0")"; DIR="$(pwd)"
echo "== CashMkr · attivazione https =="
read -p "Nome scelto su DuckDNS (es. cashmkr-gigi): " NAME
NAME="$(echo "$NAME" | tr 'A-Z' 'a-z' | sed -e 's#^https\?://##' -e 's#\.duckdns\.org.*##' -e 's#[^a-z0-9-]##g')"
[ -z "$NAME" ] && { echo "Nome vuoto."; exit 1; }
read -s -p "Token DuckDNS (incollalo, non si vede mentre scrivi): " TOKEN; echo
TOKEN="$(echo "$TOKEN" | tr -d ' \r\n')"
DOMAIN="$NAME.duckdns.org"

echo "1/5 · Aggiorno DuckDNS con l'indirizzo di questo server…"
R="$(curl -s "https://www.duckdns.org/update?domains=$NAME&token=$TOKEN&ip=")"
[ "$R" = "OK" ] || { echo "DuckDNS ha risposto \"$R\": controlla nome e token e riprova."; exit 1; }
mkdir -p "$DIR/data"
echo "url=\"https://www.duckdns.org/update?domains=$NAME&token=$TOKEN&ip=\"" > "$DIR/data/duckdns.conf"; chmod 600 "$DIR/data/duckdns.conf"
{ crontab -l 2>/dev/null | grep -v duckdns.conf || true; echo "*/5 * * * * curl -s -K $DIR/data/duckdns.conf -o /dev/null"; } | crontab -
echo "   ok: $DOMAIN punta qui e verrà riaggiornato ogni 5 minuti."

echo "2/5 · Apro le porte 80 e 443 nel firewall di Ubuntu…"
for P in 443 80; do sudo iptables -C INPUT -p tcp --dport $P -j ACCEPT 2>/dev/null || sudo iptables -I INPUT 1 -p tcp --dport $P -j ACCEPT; done
if ! command -v netfilter-persistent >/dev/null; then sudo DEBIAN_FRONTEND=noninteractive apt-get install -y -qq iptables-persistent >/dev/null; fi
sudo netfilter-persistent save >/dev/null 2>&1 || true
echo "   ok."

echo "3/5 · Installo Caddy (certificato https gratuito automatico)…"
if ! command -v caddy >/dev/null; then
  sudo apt-get install -y -qq debian-keyring debian-archive-keyring apt-transport-https curl gnupg >/dev/null
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | sudo gpg --batch --yes --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | sudo tee /etc/apt/sources.list.d/caddy-stable.list >/dev/null
  sudo apt-get update -qq >/dev/null && sudo apt-get install -y -qq caddy >/dev/null
fi
sudo tee /etc/caddy/Caddyfile >/dev/null <<CADDY
$DOMAIN {
	encode gzip
	handle /api/* {
		reverse_proxy 127.0.0.1:8787
	}
	handle {
		respond "CashMkr Server" 200
	}
}
CADDY
sudo systemctl enable caddy >/dev/null 2>&1 || true
sudo systemctl restart caddy
echo "   ok."

echo "4/5 · Accendo l'API di sola lettura di CashMkr…"
node server.js https "$DOMAIN"
sudo systemctl restart cashmkr
echo "   ok."

echo "5/5 · Prova dall'esterno (il primo certificato può richiedere fino a un minuto)…"
for i in $(seq 1 20); do
  if curl -fs --max-time 5 "https://$DOMAIN/api/ping" | grep -q cashmkr; then
    echo ""; echo "✅ Fatto: https://$DOMAIN risponde."
    echo "Ora su Telegram scrivi /app: il link e il codice comprendono il teletrasporto."
    exit 0
  fi
  sleep 4; printf "."
done
echo ""
echo "⚠ $DOMAIN non risponde ancora in https. Controlla:"
echo "  - su Oracle, nella Security List, le regole in ingresso per le porte 80 e 443 (Source 0.0.0.0/0, TCP);"
echo "  - che su duckdns.org il nome $NAME abbia l'IP di questo server ($(curl -s --max-time 5 https://api.ipify.org || echo '?'))."
echo "Poi rilancia: bash ~/cashmkr-server/attiva-https.sh"
echo "Registro di Caddy: sudo journalctl -u caddy --no-pager | tail -20"
exit 1
