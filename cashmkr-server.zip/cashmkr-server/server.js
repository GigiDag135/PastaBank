#!/usr/bin/env node
// CashMkr Server: il bot sempre acceso, per uno o più wallet Hyperliquid, comandato da Telegram.
// Stesso motore dell'app (lib/core.js, lib/engine.js, lib/hl.js): stesse strategie, classifica, short intelligenti, ordini firmati.
"use strict";
const fs = require("fs"), path = require("path"), crypto = require("crypto");
const E = require("./lib/engine.js"), Core = require("./lib/core.js"), HLM = require("./lib/hl.js");

/* ---------------- impostazioni di base ---------------- */
const DIR = process.env.CASHMKR_DATA || path.join(__dirname, "data");
const ACC_DIR = path.join(DIR, "conti");
const CFG_FILE = path.join(DIR, "config.json");
const HL_INFO = (process.env.CASHMKR_HL_URL || "https://api.hyperliquid.xyz") + "/info";   // prezzi e candele (sempre mainnet)
if (process.env.CASHMKR_HL_URL) HLM.URLS.mainnet = process.env.CASHMKR_HL_URL;
if (process.env.CASHMKR_HL_TEST_URL) HLM.URLS.testnet = process.env.CASHMKR_HL_TEST_URL;
const TG = (process.env.CASHMKR_TG_URL || "https://api.telegram.org");
const NOW_OFFSET = +process.env.CASHMKR_NOW_OFFSET || 0;          // solo per le prove
const now = () => Date.now() + NOW_OFFSET;
const BAR = 900000, DAY = 86400000, COINS = ["BTC", "ETH", "SOL", "XRP"];
const SLIP_REAL = 0.005, STEADY = { r: 3, frac: 0.5, be: 1 };
fs.mkdirSync(ACC_DIR, { recursive: true });

const readJ = (f, d) => { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch (e) { return d; } };
const writeJ = (f, o) => { const tmp = f + ".tmp"; fs.writeFileSync(tmp, JSON.stringify(o, null, 1), { mode: 0o600 }); fs.renameSync(tmp, f); };
let CFG = readJ(CFG_FILE, null);
function cfgDefaults() {
  return { telegramToken: "", setupCode: crypto.randomBytes(4).toString("hex").toUpperCase(), adminChatId: 0, invites: {}, tgOffset: 0,
    antiInattivita: true, antiCpu: 0.25 };
}
if (!CFG) { CFG = cfgDefaults(); writeJ(CFG_FILE, CFG); }
CFG = Object.assign(cfgDefaults(), CFG);
const saveCfg = () => writeJ(CFG_FILE, CFG);

/* ---------------- registro su file ---------------- */
const LOGF = path.join(DIR, "registro.log");
const stamp = t => new Date(t || now()).toISOString().replace("T", " ").slice(0, 19);
function slog(msg) { const line = stamp() + "  " + msg; console.log(line); try { fs.appendFileSync(LOGF, line + "\n"); } catch (e) {} }

/* ---------------- formati ---------------- */
const usd = v => "$" + (+v).toLocaleString("it-IT", { minimumFractionDigits: v < 10 ? 4 : 0, maximumFractionDigits: v < 10 ? 4 : v < 1000 ? 2 : 0 });
const usd2 = v => (v < 0 ? "−" : "") + "$" + Math.abs(v).toLocaleString("it-IT", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const sgn = v => (v >= 0 ? "+" : "") + usd2(v);
const todayKey = () => new Date(now()).toISOString().slice(0, 10);
const SBY = Object.fromEntries(Core.STRATEGIES.map(s => [s.id, s]));
const stratName = id => id === "manuale" ? "Manuale" : (SBY[id] ? SBY[id].title : id);

/* ================= dati di mercato (condivisi da tutti i conti) ================= */
const M = Object.fromEntries(COINS.map(c => [c, { candles: [], price: 0, priceAt: 0, daily: null, fetchAt: 0, SIG: null, sigBar: 0 }]));
let mktOk = false;
async function hlInfo(body) {
  const r = await fetch(HL_INFO, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  if (!r.ok) throw new Error("Hyperliquid HTTP " + r.status);
  return r.json();
}
const toTyped = arr => { const N = arr.length, C = { t: new Float64Array(N), o: new Float64Array(N), h: new Float64Array(N), l: new Float64Array(N), c: new Float64Array(N), v: new Float64Array(N) }; arr.forEach((x, i) => { C.t[i] = x.t; C.o[i] = x.o; C.h[i] = x.h; C.l[i] = x.l; C.c[i] = x.c; C.v[i] = x.v; }); return C; };
const mapC = d => d.map(c => ({ t: +c.t, o: +c.o, h: +c.h, l: +c.l, c: +c.c, v: +c.v }));
async function loadCandles(coin) {
  const m = M[coin], end = now(), start = m.candles.length ? m.candles[m.candles.length - 1].t - 2 * BAR : end - 5000 * BAR;
  const d = mapC(await hlInfo({ type: "candleSnapshot", req: { coin, interval: "15m", startTime: start, endTime: end } }));
  const mp = new Map(m.candles.map(c => [c.t, c])); for (const c of d) mp.set(c.t, c);
  m.candles = [...mp.values()].sort((a, b) => a.t - b.t).slice(-5200); m.fetchAt = now();
}
async function loadDaily(coin) {
  const end = now(), d = mapC(await hlInfo({ type: "candleSnapshot", req: { coin, interval: "1d", startTime: end - 320 * DAY, endTime: end } }));
  if (d.length >= 200) M[coin].daily = toTyped(d);
}
async function pollMids() {
  const d = await hlInfo({ type: "allMids" }); let ok = 0;
  for (const c of COINS) { const p = parseFloat(d[c]); if (p > 0) { M[c].price = p; M[c].priceAt = now(); ok++; } }
  mktOk = ok > 0;
}
const closed = coin => M[coin].candles.filter(c => c.t + BAR <= now());
function failReason(coin) {
  const m = M[coin];
  if (now() - m.priceAt > 120000) return "prezzo non aggiornato";
  const cl = closed(coin); if (cl.length < 300) return "candele insufficienti";
  if (now() - (cl[cl.length - 1].t + BAR) > 2 * BAR) return "ultima candela troppo vecchia";
  if (!m.daily) return "candele giornaliere mancanti";
  return "";
}
// strategie con le opzioni dell'app (predefinite: long solo con volatilità bassa, squeeze long, short intelligenti) + modalità costanza per conto
const strats = steady => Core.STRATEGIES.filter(s => s.def).map(s => Object.assign({}, s, steady ? { ex: Object.assign({}, s.ex, { part: STEADY }) } : {}));
// segnali calcolati una volta per candela chiusa, uguali per tutti i conti
function signalsFor(coin) {
  const m = M[coin], cl = closed(coin); if (cl.length < 300) return null;
  const last = cl[cl.length - 1].t;
  if (m.sigBar !== last) { m.SIG = Core.buildSignals(toTyped(cl), strats(false), m.daily ? { daily: m.daily } : { volPct: new Float64Array(cl.length).fill(NaN) }); m.sigBar = last; m.sigN = cl.length; m.sigT = cl.map(c => c.t); }
  return m;
}

/* ================= conti ================= */
const ACC = new Map();   // id -> conto
const accFile = id => path.join(ACC_DIR, id + ".json");
function newSettings() { return { bot: false, risk: Core.BEST.cfg.risk, maxPos: 4, maxLev: 40, rsTop: true, steady: false, dailyLimit: true, daily: 5, coins: Object.fromEntries(COINS.map(c => [c, true])), strats: Object.fromEntries(Core.STRATEGIES.filter(s => s.def).map(s => [s.id, true])), notify: true, weekly: true }; }
function loadAccounts() { for (const f of fs.readdirSync(ACC_DIR)) if (f.endsWith(".json")) { const a = readJ(path.join(ACC_DIR, f), null); if (a && a.id) { a.set = Object.assign(newSettings(), a.set); a.real = Object.assign({ pos: {}, history: [], day: {} }, a.real); a.lastBar = a.lastBar || {}; ACC.set(a.id, a); } } }
const saveAcc = a => writeJ(accFile(a.id), Object.assign({}, a, { _c: undefined, _w: undefined, _busy: undefined }));
const client = a => a._c || (a._c = new HLM.Client(a.net, a.address, a.key));
function alog(a, msg, notify) { slog(`[${a.name}] ${msg}`); a.log = [stamp() + "  " + msg, ...(a.log || [])].slice(0, 200); if (notify !== false && a.set.notify) tgSend(a.chatId, (a.net === "mainnet" ? "💶 " : "🧪 TESTNET · ") + msg); }

/* ---------- ordini veri (stessa logica dell'app) ---------- */
let queue = Promise.resolve();
const enqueue = fn => (queue = queue.then(fn).catch(e => slog("errore: " + e.message)));
async function refreshAcc(a) {
  const c = client(a);
  const [acc, orders, mids] = await Promise.all([c.account(), c.openOrders(), c.mids()]);
  a._w = { acc, orders, mids: mids || {}, at: now() };
  const k = todayKey();
  if (a.real.day.key !== k) a.real.day = { key: k, startEq: acc.equity, locked: "" };
  if (a.set.dailyLimit && a.real.day.locked !== k && a.real.day.startEq > 0 && acc.equity < a.real.day.startEq * (1 - a.set.daily / 100)) {
    a.real.day.locked = k; alog(a, `Perdita di oggi oltre il ${a.set.daily}%: niente nuovi ordini fino a domani (UTC).`);
  }
  return a._w;
}
const stopOrders = (a, coin) => (a._w ? a._w.orders : []).filter(o => o.coin === coin && o.isTrigger && o.reduceOnly);
const midOf = (a, coin) => parseFloat((a._w && a._w.mids[coin]) || 0) || M[coin].price;
async function pnlSince(a, coin, t) { try { const f = await client(a).fills(t - 60000); let p = 0, fee = 0; for (const x of f) if (x.coin === coin) { p += +x.closedPnl || 0; fee += +x.fee || 0; } return p - fee; } catch (e) { return NaN; } }
async function recordClose(a, coin, why) {
  const P = a.real.pos[coin]; if (!P) return;
  const pnl = await pnlSince(a, coin, P.opened);
  a.real.history.push({ coin, strat: P.strat, side: P.side, entry: P.entry, size: P.size, opened: P.opened, closed: now(), why, pnl });
  a.real.history = a.real.history.slice(-500);
  delete a.real.pos[coin]; saveAcc(a);
  alog(a, `${coin} · chiuso ${P.side > 0 ? "LONG" : "SHORT"} · ${stratName(P.strat)} · ${why}${isNaN(pnl) ? "" : ": " + sgn(pnl)}`);
}
async function manageAcc(a) {
  const w = a._w; if (!w) return;
  // posizioni sparite dall'exchange = chiuse da stop o obiettivo
  for (const coin of Object.keys(a.real.pos)) {
    const P = a.real.pos[coin], pos = w.acc.positions[coin];
    if (!pos) { await recordClose(a, coin, "chiusa dall'exchange (stop o obiettivo)"); try { await client(a).cancelTriggers(coin); } catch (e) {} continue; }
    const side = +pos.szi > 0 ? 1 : -1; if (side !== P.side) continue;
    const meta = await client(a).coinMeta(coin), mid = midOf(a, coin);
    P.size = Math.abs(+pos.szi);
    if (!stopOrders(a, coin).length && now() - P.opened > 4000) {
      try { await client(a).placeStop(coin, P.side < 0, P.size, P.sl); alog(a, `${coin}: stop mancante, rimesso sull'exchange.`); }
      catch (e) { alog(a, `${coin}: stop non impostabile (${e.message}), chiudo per sicurezza.`); await doClose(a, coin, "sicurezza: stop non attivo"); continue; }
    }
    if (P.ex && P.ex.part && !P.partDone && mid && (P.side > 0 ? mid >= P.entry + P.ex.part.r * P.slD : mid <= P.entry - P.ex.part.r * P.slD)) {
      const sz = HLM.roundSz(P.size * P.ex.part.frac, meta.szDecimals);
      try {
        if (sz * mid >= 10.5 && P.size - sz > 0) { await client(a).reduceMarket(coin, P.side < 0, sz, SLIP_REAL); P.size = +(P.size - sz).toFixed(meta.szDecimals); alog(a, `${coin}: uscita parziale, chiusi ${sz} ${coin}.`); }
        P.partDone = true;
        const be = P.entry * (1 + P.side * 2 * Core.DEFAULTS.fee), old = stopOrders(a, coin);
        await client(a).placeStop(coin, P.side < 0, P.size, be); for (const o of old) { try { await client(a).cancel(coin, o.oid); } catch (e) {} }
        P.beDone = true; P.sl = be; saveAcc(a); alog(a, `${coin}: stop della parte rimasta a pareggio.`);
      } catch (e) { alog(a, `${coin}: uscita parziale non riuscita, riprovo: ${e.message}`, false); }
    }
  }
}
async function doClose(a, coin, why) {
  try { await client(a).closeMarket(coin, SLIP_REAL); await new Promise(r => setTimeout(r, 1500)); await recordClose(a, coin, why); }
  catch (e) { alog(a, `${coin}: chiusura non riuscita: ${e.message}`); }
}
function blocked(a, coin, t) {
  if (!a.set.bot) return "bot fermo";
  if (!a.key) return "chiave mancante";
  if (!a.set.coins[coin]) return coin + " spenta";
  const fr = failReason(coin); if (fr) return "blocco di sicurezza (" + fr + ")";
  if (a.set.dailyLimit && a.real.day.locked === todayKey()) return "perdita giornaliera massima raggiunta";
  return "";
}
const coinsOn = a => COINS.filter(c => a.set.coins[c]);
const ranks = (a, t) => Core.rsRanks(Object.fromEntries(coinsOn(a).map(c => [c, M[c].daily])), t, Core.RS.lbs);
async function doOpen(a, coin, s, side, slPct) {
  try {
    const c = client(a), [acc, mid, meta] = await Promise.all([c.account(), c.mid(coin), c.coinMeta(coin)]);
    if (acc.positions[coin] || a.real.pos[coin]) return alog(a, `${coin}: segnale ${s.title} non eseguito, c'è già una posizione su ${coin}.`, false);
    const nBot = Object.keys(a.real.pos).length; if (nBot >= a.set.maxPos) return alog(a, `${coin}: segnale non eseguito, già ${nBot} posizioni (limite ${a.set.maxPos}).`, false);
    const lev = Math.max(1, Math.min(Math.floor(1 / (slPct * 1.5 + Core.DEFAULTS.mmr)), meta.maxLeverage, a.set.maxLev));
    let notional = acc.equity * a.set.risk / 100 / (slPct + 2 * Core.DEFAULTS.fee + 0.0005);
    if (notional / lev > acc.available * 0.95) notional = acc.available * 0.95 * lev;
    const sz = HLM.roundSz(notional / mid, meta.szDecimals);
    if (sz * mid < 10.5) return alog(a, `${coin}: ordine non inviato, valore ${usd2(sz * mid)} sotto il minimo di 10 $ (conto ${usd2(acc.equity)}).`);
    const sl = mid * (1 - side * slPct);
    await c.setLeverage(coin, lev);
    const st = await c.openProtected(coin, side > 0, sz, mid, sl, 0, SLIP_REAL), f = st[0] && st[0].filled;
    if (!f) return alog(a, `${coin}: ordine rifiutato: ` + ((st[0] && st[0].error) || JSON.stringify(st[0])));
    const entry = +f.avgPx, size = +f.totalSz, ex = a.set.steady ? Object.assign({}, s.ex, { part: STEADY }) : s.ex;
    a.real.pos[coin] = { coin, strat: s.id, side, size, entry, sl, slD: Math.abs(entry - sl), lev, beDone: false, ex, opened: now() };
    saveAcc(a);
    alog(a, `${coin} · aperto ${side > 0 ? "LONG" : "SHORT"} · ${s.title} · ${size} ${coin} a ${usd(entry)} · leva ${lev}x · stop ${usd(sl)} · rischio ${a.set.risk}%`);
  } catch (e) { alog(a, `${coin}: errore nell'invio dell'ordine: ${e.message}`); }
}
// a ogni candela chiusa: uscite al segnale opposto e nuove entrate, per ogni conto
function onBar(coin) {
  const m = signalsFor(coin); if (!m) return;
  const i = m.sigN - 1, barT = m.sigT[i], live = now() - (barT + BAR) < 10 * 60000, SIG = m.SIG;
  for (const a of ACC.values()) {
    if ((a.lastBar[coin] || 0) >= barT) continue; a.lastBar[coin] = barT;
    if (!a.key) continue;
    const P = a.real.pos[coin];
    if (P && P.strat !== "manuale" && SIG[P.strat] && SIG[P.strat].raw[i] === -P.side) enqueue(() => doClose(a, coin, "Segnale opposto").then(() => refreshAcc(a)));
    if (!live) continue;
    for (const s of strats(a.set.steady)) {
      const x = SIG[s.id], d = x.sig[i]; if (!d || isNaN(x.A[i]) || !a.set.strats[s.id]) continue;
      const nm = `${coin} · segnale ${d > 0 ? "LONG" : "SHORT"} di ${s.title}`;
      const why = blocked(a, coin);
      if (why) { if (a.set.bot) alog(a, `${nm} ignorato: ${why}.`, false); continue; }
      const t = barT + BAR;
      if (s.smart) { const rw = Core.smartShortReason(ranks(a, t), coin, M.BTC.daily, t); if (rw) { alog(a, `${nm} ignorato: ${rw}.`, false); continue; } }
      else if (a.set.rsTop) { const r = ranks(a, t)[coin]; if (r == null || r >= Core.RS.top) { alog(a, `${nm} ignorato: ${coin} è ${r == null ? "?" : r + 1}ª in classifica, non tra le prime ${Core.RS.top}.`, false); continue; } }
      const slPct = s.ex.sl * x.A[i] / (M[coin].price || m.candles[m.candles.length - 1].c);
      enqueue(() => doOpen(a, coin, s, d, slPct).then(() => refreshAcc(a).catch(() => {})));
      break; // una posizione per moneta
    }
    saveAcc(a);
  }
}

/* ================= resoconto settimanale ================= */
// settimana da lunedì 00:00 (ora italiana) letta dagli eseguiti di Hyperliquid: include anche le operazioni chiuse a mano
const romeOffset = t => { const d = new Date(t); const s = d.toLocaleString("en-US", { timeZone: "Europe/Rome" }); return new Date(s).getTime() - new Date(d.toLocaleString("en-US", { timeZone: "UTC" })).getTime(); };
function weekStartRome(t) { const off = romeOffset(t), d = new Date(t + off); const wd = (d.getUTCDay() + 6) % 7; d.setUTCHours(0, 0, 0, 0); return d.getTime() - wd * DAY - off; }
async function weekReport(a, w0) {
  const w1 = w0 + 7 * DAY;
  let F = []; try { F = (await client(a).fills(w0)).filter(f => +f.time < w1); } catch (e) { return "Non riesco a leggere le operazioni da Hyperliquid: " + e.message; }
  const isClose = f => f.dir ? /^Close|>|Liquidat/i.test(f.dir) : Math.abs(+f.closedPnl || 0) > 0;
  const grp = arr => { const out = []; for (const f of arr.sort((x, y) => x.time - y.time)) { const g = out.find(o => o.coin === f.coin && Math.abs(f.time - o.last) < 120000); if (g) { g.pnl += (+f.closedPnl || 0) - (+f.fee || 0); g.last = +f.time; } else out.push({ coin: f.coin, last: +f.time, pnl: (+f.closedPnl || 0) - (+f.fee || 0) }); } return out; };
  const opens = grp(F.filter(f => !isClose(f))), closes = grp(F.filter(isClose)), tot = F.reduce((x, f) => x + (+f.closedPnl || 0) - (+f.fee || 0), 0), won = closes.filter(o => o.pnl > 0).length;
  const w = a._w, ps = w ? Object.entries(w.acc.positions) : [], un = ps.reduce((x, [, p]) => x + (+p.unrealizedPnl || 0), 0);
  const dd = t => new Date(t).toLocaleDateString("it-IT", { day: "2-digit", month: "2-digit", timeZone: "Europe/Rome" });
  return `📅 Settimana ${dd(w0)} → ${dd(w1 - 1)} · ${a.name} (${a.net})\nTotale: ${sgn(tot)}\nAperte ${opens.length} · chiuse ${closes.length} (vinte ${won}, perse ${closes.length - won})` +
    (closes.length ? "\n" + closes.map(o => `• ${new Date(o.last).toLocaleString("it-IT", { weekday: "short", hour: "2-digit", minute: "2-digit", timeZone: "Europe/Rome" })} ${o.coin}: ${sgn(o.pnl)}`).join("\n") : "") +
    `\n${ps.length ? "Ancora aperte: " + ps.map(([c, p]) => c + (+p.szi > 0 ? " long" : " short")).join(", ") + " · non realizzato " + sgn(un) : "Nessuna posizione aperta."}` + (w ? `\nConto: ${usd2(w.acc.equity)}` : "");
}
// domenica alle 20:00 (ora italiana) il riepilogo arriva da solo a chi ha l'opzione accesa
let lastWeekly = readJ(path.join(DIR, "settimanale.json"), {});
function weeklyTick() {
  const t = now(), off = romeOffset(t), d = new Date(t + off);
  if (d.getUTCDay() !== 0 || d.getUTCHours() < 20) return;
  const key = d.toISOString().slice(0, 10);
  for (const a of ACC.values()) if (a.set.weekly && a.chatId && lastWeekly[a.id] !== key) { lastWeekly[a.id] = key; writeJ(path.join(DIR, "settimanale.json"), lastWeekly); weekReport(a, weekStartRome(t)).then(m => tgSend(a.chatId, m)); }
}

/* ================= Telegram ================= */
async function tg(method, body) {
  if (!CFG.telegramToken) return null;
  try { const r = await fetch(`${TG}/bot${CFG.telegramToken}/${method}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) }); return await r.json(); }
  catch (e) { slog("Telegram non raggiungibile: " + e.message); return null; }
}
const KB = { keyboard: [[{ text: "/stato" }, { text: "/posizioni" }, { text: "/settimana" }], [{ text: "/avvia" }, { text: "/ferma" }], [{ text: "/classifica" }, { text: "/aiuto" }]], resize_keyboard: true };
function tgSend(chatId, text) { if (chatId) tg("sendMessage", { chat_id: chatId, text, reply_markup: KB, disable_web_page_preview: true }); }
const accOf = chatId => [...ACC.values()].find(a => a.chatId === chatId);
const HELP = `Comandi CashMkr:
/stato — conto, bot acceso o fermo, impostazioni
/posizioni — posizioni aperte e protezioni
/storico — ultime operazioni chiuse
/avvia — accende il tuo bot · /ferma — lo spegne
/rischio 0.75 — rischio per operazione in % (da 0,1 a 3)
/maxpos 2 — posizioni insieme al massimo (1-4)
/moneta SOL off — accende o spegne una moneta
/strategia kelS off — accende o spegne una strategia (kel1h, mom1h, sq4h, kelS)
/classifica — moneta più forte e mercato in discesa
/settimana — resoconto della settimana (operazioni aperte, chiuse, totale)
/opzione costanza on — modalità costanza · /opzione classifica off — solo le 2 più forti
/opzione blocco on — blocco perdita giornaliera · /opzione avvisi off — niente messaggi a ogni operazione
/opzione settimanale off — niente riepilogo automatico della domenica sera
/chiudi — chiude subito tutte le tue posizioni (chiede conferma)
/scollega — toglie il tuo wallet dal server`;
async function onMessage(msg) {
  const chatId = msg.chat && msg.chat.id, text = (msg.text || "").trim(); if (!chatId || !text) return;
  const [cmd0, ...args] = text.split(/\s+/), cmd = cmd0.toLowerCase().replace(/@.*/, "");
  const a = accOf(chatId), admin = CFG.adminChatId && chatId === CFG.adminChatId;
  if (cmd === "/start") return tgSend(chatId, `Ciao! Questo è il bot CashMkr.\n${a ? "Il tuo wallet è collegato: scrivi /stato." : "Per collegare il tuo wallet ti serve un codice di invito: chiedilo a chi gestisce il server, poi scrivi\n/collega CODICE INDIRIZZO CHIAVE"}\n\nIl tuo numero Telegram: ${chatId}`);
  if (cmd === "/admin") { if (args[0] && args[0].toUpperCase() === CFG.setupCode) { CFG.adminChatId = chatId; saveCfg(); return tgSend(chatId, "Sei l'amministratore del server.\n/invita Nome mainnet (o testnet) — crea un codice per collegare un wallet\n/utenti — elenco dei conti\n/fermatutti — ferma tutti i bot"); } return tgSend(chatId, "Codice non valido."); }
  if (cmd === "/invita") {
    if (!admin) return tgSend(chatId, "Solo l'amministratore può creare inviti.");
    const name = (args[0] || "").replace(/[^\p{L}\p{N}_-]/gu, "").slice(0, 20), net = (args[1] || "mainnet").toLowerCase() === "testnet" ? "testnet" : "mainnet";
    if (!name) return tgSend(chatId, "Scrivi /invita Nome mainnet (oppure testnet).");
    const code = crypto.randomBytes(3).toString("hex").toUpperCase(); CFG.invites[code] = { name, net, exp: now() + 2 * DAY }; saveCfg();
    return tgSend(chatId, `Invito per ${name} (${net}), valido 48 ore.\nCodice: ${code}\n\n${name} deve aprire questo bot su Telegram e scrivere:\n/collega ${code} INDIRIZZO_WALLET CHIAVE_API_WALLET\n(il messaggio viene cancellato subito dopo la lettura)`);
  }
  if (cmd === "/utenti") { if (!admin) return; return tgSend(chatId, [...ACC.values()].map(x => `${x.name} · ${x.net} · ${x.set.bot ? "acceso" : "fermo"} · rischio ${x.set.risk}% · posizioni ${Object.keys(x.real.pos).join(", ") || "nessuna"}${x._w ? " · conto " + usd2(x._w.acc.equity) : ""}`).join("\n") || "Nessun conto collegato."); }
  if (cmd === "/fermatutti") { if (!admin) return; for (const x of ACC.values()) { x.set.bot = false; saveAcc(x); alog(x, "Bot fermato dall'amministratore."); } return tgSend(chatId, "Tutti i bot fermati (le posizioni aperte restano protette dai loro stop)."); }
  if (cmd === "/collega") {
    tg("deleteMessage", { chat_id: chatId, message_id: msg.message_id });   // la chiave non resta nella chat
    const inv = CFG.invites[(args[0] || "").toUpperCase()];
    if (!inv || inv.exp < now()) return tgSend(chatId, "Codice di invito non valido o scaduto. Il tuo messaggio è stato cancellato.");
    const addr = (args[1] || "").replace(/\s/g, ""), key0 = (args[2] || "").replace(/\s/g, ""), key = key0.startsWith("0x") ? key0 : "0x" + key0;
    if (!/^0x[0-9a-fA-F]{40}$/.test(addr)) return tgSend(chatId, "Indirizzo del wallet non valido: deve essere 0x seguito da 40 caratteri (42 in tutto). Il messaggio è stato cancellato.");
    if (!/^0x[0-9a-fA-F]{64}$/.test(key)) return tgSend(chatId, `Chiave non valida: deve essere 0x seguito da 64 caratteri (66 in tutto), ne hai mandati ${key0.length}.${key0.length === 42 ? " Sembra un indirizzo: serve la CHIAVE PRIVATA dell'API wallet." : ""} Il messaggio è stato cancellato.`);
    if (a) return tgSend(chatId, "Hai già un wallet collegato. Scrivi prima /scollega.");
    const id = inv.name.toLowerCase() + "-" + crypto.randomBytes(2).toString("hex");
    const acc = { id, name: inv.name, net: inv.net, address: addr, key, chatId, set: newSettings(), real: { pos: {}, history: [], day: {} }, lastBar: {}, log: [], created: now() };
    const c = new HLM.Client(acc.net, addr, key);
    if (c.agentAddress().toLowerCase() === addr.toLowerCase()) return tgSend(chatId, "Questa sembra la chiave del wallet PRINCIPALE: non usarla. Crea un API wallet su Hyperliquid e manda la sua chiave. Il messaggio è stato cancellato.");
    try {
      const v = await c.verify(); if (!v.ok) return tgSend(chatId, "Verifica non riuscita: " + v.msg + "\nControlla di aver autorizzato l'API wallet sul conto giusto e sulla rete giusta (" + acc.net + ").");
      delete CFG.invites[(args[0] || "").toUpperCase()]; saveCfg();
      ACC.set(id, acc); saveAcc(acc); await refreshAcc(acc).catch(() => {});
      slog(`Nuovo conto collegato: ${acc.name} (${acc.net})`);
      return tgSend(chatId, `Wallet collegato e verificato (${acc.net}). ${acc._w ? "Valore del conto: " + usd2(acc._w.acc.equity) + "." : ""}\nIl tuo messaggio con la chiave è stato cancellato.\nIl bot è FERMO: controlla le impostazioni con /stato e scrivi /avvia quando vuoi partire.\n\n` + HELP);
    } catch (e) { return tgSend(chatId, "Verifica non riuscita: " + e.message); }
  }
  if (!a) return tgSend(chatId, "Non hai un wallet collegato. Ti serve un codice di invito, poi /collega CODICE INDIRIZZO CHIAVE.");
  const s = a.set;
  const on = v => /^(on|si|sì|1|acceso|accendi)$/i.test(v || ""), off = v => /^(off|no|0|spento|spegni)$/i.test(v || "");
  switch (cmd) {
    case "/aiuto": case "/help": return tgSend(chatId, HELP);
    case "/avvia": s.bot = true; saveAcc(a); return tgSend(chatId, `▶ Bot avviato (${a.net}). Rischio ${s.risk}% · max ${s.maxPos} posizioni · monete ${coinsOn(a).join(", ")}.`);
    case "/ferma": s.bot = false; saveAcc(a); return tgSend(chatId, "■ Bot fermato: niente nuove entrate. Le posizioni aperte restano protette dai loro stop sull'exchange (/chiudi per chiuderle).");
    case "/rischio": { const v = parseFloat((args[0] || "").replace(",", ".")); if (!(v >= 0.1 && v <= 3)) return tgSend(chatId, "Scrivi un valore tra 0,1 e 3, per esempio /rischio 0.75"); s.risk = Math.round(v * 100) / 100; saveAcc(a); return tgSend(chatId, `Rischio per operazione: ${s.risk}%.`); }
    case "/maxpos": { const v = parseInt(args[0]); if (!(v >= 1 && v <= 4)) return tgSend(chatId, "Scrivi un numero da 1 a 4."); s.maxPos = v; saveAcc(a); return tgSend(chatId, `Posizioni insieme al massimo: ${v}.`); }
    case "/moneta": { const c = (args[0] || "").toUpperCase(); if (!COINS.includes(c) || !(on(args[1]) || off(args[1]))) return tgSend(chatId, "Scrivi per esempio /moneta SOL off"); s.coins[c] = on(args[1]); saveAcc(a); return tgSend(chatId, `${c}: ${s.coins[c] ? "accesa" : "spenta"}. Monete accese: ${coinsOn(a).join(", ") || "nessuna"}.`); }
    case "/strategia": { const id = Object.keys(s.strats).find(k => k.toLowerCase() === (args[0] || "").toLowerCase()); if (!id || !(on(args[1]) || off(args[1]))) return tgSend(chatId, "Scrivi per esempio /strategia kelS off (strategie: kel1h, mom1h, sq4h, kelS)"); s.strats[id] = on(args[1]); saveAcc(a); return tgSend(chatId, `${stratName(id)}: ${s.strats[id] ? "accesa" : "spenta"}.`); }
    case "/opzione": {
      const map = { costanza: "steady", classifica: "rsTop", blocco: "dailyLimit", avvisi: "notify", settimanale: "weekly" }, k = map[(args[0] || "").toLowerCase()];
      if (!k || !(on(args[1]) || off(args[1]))) return tgSend(chatId, "Opzioni: costanza, classifica, blocco, avvisi, settimanale. Esempio: /opzione costanza on");
      s[k] = on(args[1]); saveAcc(a); return tgSend(chatId, `${args[0]}: ${s[k] ? "acceso" : "spento"}.`);
    }
    case "/stato": {
      const w = a._w, eq = w ? w.acc.equity : null, d0 = a.real.day.startEq;
      const fr = COINS.map(c => failReason(c)).filter(Boolean);
      return tgSend(chatId, `${a.name} · ${a.net === "mainnet" ? "MAINNET (soldi veri)" : "TESTNET (prova)"}\nBot: ${s.bot ? "▶ ACCESO" : "■ FERMO"}${fr.length ? " · ⚠ dati di mercato: " + fr[0] : ""}${s.dailyLimit && a.real.day.locked === todayKey() ? "\n⚠ Perdita giornaliera raggiunta: niente nuove entrate fino a domani" : ""}\nConto: ${eq != null ? usd2(eq) : "—"}${eq != null && d0 ? " · oggi " + sgn(eq - d0) : ""}\nPosizioni: ${Object.keys(a.real.pos).join(", ") || "nessuna"}\n\nRischio ${s.risk}% · max ${s.maxPos} posizioni · leva max ${s.maxLev}x\nMonete: ${coinsOn(a).join(", ")}\nStrategie: ${Object.entries(s.strats).filter(([, v]) => v).map(([k]) => stratName(k)).join(", ")}\nSolo le 2 più forti: ${s.rsTop ? "sì" : "no"} · costanza: ${s.steady ? "sì" : "no"} · blocco giornaliero ${s.dailyLimit ? s.daily + "%" : "spento"} · avvisi: ${s.notify ? "sì" : "no"}`);
    }
    case "/posizioni": {
      const w = a._w; if (!w) return tgSend(chatId, "Conto non ancora letto, riprova tra qualche secondo.");
      const ps = Object.entries(w.acc.positions);
      return tgSend(chatId, ps.length ? ps.map(([c, p]) => { const P = a.real.pos[c], so = stopOrders(a, c); return `${c}: ${+p.szi > 0 ? "LONG" : "SHORT"} ${Math.abs(+p.szi)} · entrata ${usd(+p.entryPx)} · G/P ${sgn(+p.unrealizedPnl)}\n   stop: ${so.length ? so.map(o => usd(+o.triggerPx)).join(", ") : "⚠ nessuno"}${P ? " · " + stratName(P.strat) : " · non aperta dal bot"}`; }).join("\n") : "Nessuna posizione aperta.");
    }
    case "/storico": { const H = a.real.history.slice(-10).reverse(); const tot = a.real.history.reduce((x, h) => x + (isNaN(h.pnl) ? 0 : h.pnl), 0); return tgSend(chatId, H.length ? H.map(h => `${stamp(h.closed).slice(5, 16)} ${h.coin} ${h.side > 0 ? "L" : "S"} ${stratName(h.strat)}: ${isNaN(h.pnl) ? "?" : sgn(h.pnl)} (${h.why})`).join("\n") + `\n\nTotale ${a.real.history.length} operazioni: ${sgn(tot)}` : "Ancora nessuna operazione chiusa."); }
    case "/classifica": {
      const t = now(), rk = ranks(a, t), ord = coinsOn(a).slice().sort((x, y) => (rk[x] ?? 9) - (rk[y] ?? 9)), down = Core.btcDown(M.BTC.daily, t, 100);
      return tgSend(chatId, `Classifica (3, 7, 14 giorni):\n${ord.map((c, i) => `${i + 1}. ${c}${i < Core.RS.top ? " · long possibili" : ""}`).join("\n")}\n\nBTC ${down ? "SOTTO la media di 100 giorni: short intelligenti possibili su " + ord[ord.length - 1] : "sopra la media di 100 giorni: niente short"}.`);
    }
    case "/settimana": { const prev = /^(scorsa|prec)/i.test(args[0] || ""); const w0 = weekStartRome(now()) - (prev ? 7 * DAY : 0); return tgSend(chatId, await weekReport(a, w0)); }
    case "/chiudi": {
      if ((args[0] || "").toUpperCase() !== "SI") return tgSend(chatId, "Chiudere ADESSO a mercato tutte le tue posizioni? Scrivi /chiudi SI per confermare.");
      const cs = a._w ? Object.keys(a._w.acc.positions) : []; if (!cs.length) return tgSend(chatId, "Nessuna posizione da chiudere.");
      for (const c of cs) enqueue(() => a.real.pos[c] ? doClose(a, c, "chiusa a mano") : client(a).closeMarket(c, SLIP_REAL).then(() => alog(a, `${c}: chiusa a mano.`)));
      return tgSend(chatId, "Chiusura in corso…");
    }
    case "/scollega": {
      if (Object.keys(a.real.pos).length && (args[0] || "").toUpperCase() !== "SI") return tgSend(chatId, "Hai posizioni aperte gestite dal bot: restano aperte con il loro stop ma il bot smette di seguirle. Scrivi /scollega SI per confermare.");
      ACC.delete(a.id); try { fs.unlinkSync(accFile(a.id)); } catch (e) {} slog(`Conto scollegato: ${a.name}`);
      return tgSend(chatId, "Wallet scollegato: la chiave è stata cancellata dal server. Per sicurezza puoi anche eliminare l'API wallet dal sito di Hyperliquid.");
    }
    default: return tgSend(chatId, "Comando non riconosciuto. " + HELP);
  }
}
async function tgLoop() {
  while (true) {
    if (!CFG.telegramToken) { await new Promise(r => setTimeout(r, 5000)); continue; }
    const r = await tg("getUpdates", { offset: CFG.tgOffset, timeout: 25, allowed_updates: ["message"] });
    if (!r || !r.ok) { await new Promise(r2 => setTimeout(r2, 5000)); continue; }
    for (const u of r.result) { CFG.tgOffset = u.update_id + 1; saveCfg(); if (u.message) await onMessage(u.message).catch(e => slog("errore comando: " + e.message)); }
  }
}

/* ================= anti-inattività di Oracle (interruttore in config.json) ================= */
// Oracle può recuperare i server "Always Free" che restano quasi fermi per 7 giorni (processore sotto il 20%).
// Con antiInattivita acceso un lavoro a bassissima priorità tiene il processore poco sopra la soglia; si ferma da solo se serve al bot.
function antiIdle() {
  if (!CFG.antiInattivita || process.env.CASHMKR_NO_ANTIIDLE) return;
  const { Worker } = require("worker_threads"), n = require("os").cpus().length, duty = Math.min(0.9, CFG.antiCpu);
  for (let i = 0; i < n; i++) new Worker(`const d=${duty};function loop(){const t=Date.now();while(Date.now()-t<100*d){Math.sqrt(Math.random())}setTimeout(loop,100*(1-d))}loop()`, { eval: true });
  try { require("os").setPriority(19); } catch (e) {}
  slog(`Anti-inattività attivo: circa ${Math.round(duty * 100)}% del processore a bassa priorità (spegnibile in config.json).`);
}

/* ================= avvio ================= */
async function marketLoop() {
  let lastDaily = 0;
  for (;;) {
    try {
      await pollMids();
      if (now() - lastDaily > 3600000) { for (const c of COINS) await loadDaily(c); lastDaily = now(); }
      // candele: subito dopo ogni chiusura da 15 minuti, e comunque ogni minuto
      for (const c of COINS) if (!M[c].candles.length || now() - M[c].fetchAt > 60000 || Math.floor(now() / BAR) !== Math.floor(M[c].fetchAt / BAR)) await loadCandles(c);
      for (const c of COINS) onBar(c);
    } catch (e) { slog("dati di mercato non disponibili: " + e.message); }
    try { weeklyTick(); } catch (e) {}
    // conti: lettura e protezione ogni 15 secondi
    for (const a of ACC.values()) if (a.key) await enqueue(() => refreshAcc(a).then(() => manageAcc(a)).catch(e => slog(`[${a.name}] lettura del conto non riuscita: ${e.message}`)));
    await new Promise(r => setTimeout(r, +process.env.CASHMKR_LOOP_MS || 15000));
  }
}
async function main() {
  const arg = process.argv[2];
  if (arg === "token") { CFG.telegramToken = (process.argv[3] || "").trim(); saveCfg(); console.log("Token Telegram salvato."); return; }
  if (arg === "codice") { console.log("Codice amministratore: " + CFG.setupCode + "\nScrivi al bot su Telegram: /admin " + CFG.setupCode); return; }
  if (arg === "stato") { loadAccounts(); for (const a of ACC.values()) console.log(`${a.name} · ${a.net} · ${a.set.bot ? "acceso" : "fermo"} · rischio ${a.set.risk}% · posizioni ${Object.keys(a.real.pos).join(", ") || "nessuna"}`); if (!ACC.size) console.log("Nessun conto collegato."); return; }
  loadAccounts();
  slog(`CashMkr Server avviato · ${ACC.size} conti · Telegram ${CFG.telegramToken ? "configurato" : "NON configurato (node server.js token TOKEN)"}`);
  if (!CFG.adminChatId) slog(`Per diventare amministratore scrivi al bot su Telegram: /admin ${CFG.setupCode}`);
  antiIdle();
  tgLoop();
  marketLoop();
}
process.on("unhandledRejection", e => slog("errore: " + (e && e.message)));
module.exports = { onMessage, ACC, M, CFG };
if (require.main === module) main();
