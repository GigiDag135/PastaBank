#!/usr/bin/env node
// CashMkr Server: il bot sempre acceso, per uno o più wallet Hyperliquid, comandato da Telegram.
// Stesso motore dell'app (lib/core.js, lib/engine.js, lib/hl.js): stesse strategie, classifica, short intelligenti, ordini firmati.
"use strict";
const fs = require("fs"), path = require("path"), crypto = require("crypto");
const E = require("./lib/engine.js"), Core = require("./lib/core.js"), HLM = require("./lib/hl.js"), Esporta = require("./lib/esporta.js");

/* ---------------- impostazioni di base ---------------- */
const DIR = process.env.CASHMKR_DATA || path.join(__dirname, "data");
const ACC_DIR = path.join(DIR, "conti");
const CFG_FILE = path.join(DIR, "config.json");
const HL_INFO = (process.env.CASHMKR_HL_URL || "https://api.hyperliquid.xyz") + "/info";   // prezzi e candele (sempre mainnet)
if (process.env.CASHMKR_HL_URL) HLM.URLS.mainnet = process.env.CASHMKR_HL_URL;
if (process.env.CASHMKR_HL_TEST_URL) HLM.URLS.testnet = process.env.CASHMKR_HL_TEST_URL;
const TG = (process.env.CASHMKR_TG_URL || "https://api.telegram.org");
const NOW_OFFSET = +process.env.CASHMKR_NOW_OFFSET || 0;          // solo per le prove
const now = () => Date.now() + NOW_OFFSET;
const BAR = 900000, DAY = 86400000, COINS = ["BTC", "ETH", "SOL", "XRP"];
const SLIP_REAL = 0.005, STEADY = { r: 3, frac: 0.5, be: 1 };
fs.mkdirSync(ACC_DIR, { recursive: true });

const readJ = (f, d) => { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch (e) { return d; } };
const writeJ = (f, o) => { const tmp = f + ".tmp"; fs.writeFileSync(tmp, JSON.stringify(o, null, 1), { mode: 0o600 }); fs.renameSync(tmp, f); };
let CFG = readJ(CFG_FILE, null);
function cfgDefaults() {
  return { telegramToken: "", setupCode: crypto.randomBytes(4).toString("hex").toUpperCase(), adminChatId: 0, invites: {}, tgOffset: 0,
    antiInattivita: true, antiCpu: 0.25, appUrl: "https://gigidag135.github.io/PastaBank/", apiOn: false, apiHost: "", apiPort: 8787, jerikoUrl: "https://jeriko-os.pages.dev", resocontoJeriko: true, jerikoSecret: "" };
}
if (!CFG) { CFG = cfgDefaults(); writeJ(CFG_FILE, CFG); }
CFG = Object.assign(cfgDefaults(), CFG);
const saveCfg = () => writeJ(CFG_FILE, CFG);
if (!CFG.jerikoSecret) { CFG.jerikoSecret = crypto.randomBytes(16).toString("hex"); saveCfg(); }   // segreto per il resoconto a Jeriko OS (node server.js jeriko)

/* ---------------- registro su file ---------------- */
const LOGF = path.join(DIR, "registro.log");
const stamp = t => new Date(t || now()).toISOString().replace("T", " ").slice(0, 19);
function slog(msg) { const line = stamp() + "  " + msg; console.log(line); try { fs.appendFileSync(LOGF, line + "\n"); } catch (e) {} }

/* ---------------- formati ---------------- */
const usd = v => "$" + (+v).toLocaleString("it-IT", { minimumFractionDigits: v < 10 ? 4 : 0, maximumFractionDigits: v < 10 ? 4 : v < 1000 ? 2 : 0 });
const usd2 = v => (v < 0 ? "−" : "") + "$" + Math.abs(v).toLocaleString("it-IT", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const sgn = v => (v >= 0 ? "+" : "") + usd2(v);
const todayKey = () => new Date(now()).toISOString().slice(0, 10);
const SBY = Object.fromEntries(Core.STRATEGIES.map(s => [s.id, s]));
const stratName = id => id === "manuale" ? "Manuale" : (SBY[id] ? SBY[id].title : id);

/* ================= dati di mercato (condivisi da tutti i conti) ================= */
const M = Object.fromEntries(COINS.map(c => [c, { candles: [], price: 0, priceAt: 0, daily: null, fetchAt: 0, SIG: null, sigBar: 0 }]));
let mktOk = false; const BOOT = Date.now();
async function hlInfo(body) {
  const r = await fetch(HL_INFO, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  if (!r.ok) throw new Error("Hyperliquid HTTP " + r.status);
  return r.json();
}
const toTyped = arr => { const N = arr.length, C = { t: new Float64Array(N), o: new Float64Array(N), h: new Float64Array(N), l: new Float64Array(N), c: new Float64Array(N), v: new Float64Array(N) }; arr.forEach((x, i) => { C.t[i] = x.t; C.o[i] = x.o; C.h[i] = x.h; C.l[i] = x.l; C.c[i] = x.c; C.v[i] = x.v; }); return C; };
const mapC = d => d.map(c => ({ t: +c.t, o: +c.o, h: +c.h, l: +c.l, c: +c.c, v: +c.v }));
async function loadCandles(coin) {
  const m = M[coin], end = now(), start = m.candles.length ? m.candles[m.candles.length - 1].t - 2 * BAR : end - 5000 * BAR;
  const d = mapC(await hlInfo({ type: "candleSnapshot", req: { coin, interval: "15m", startTime: start, endTime: end } }));
  const mp = new Map(m.candles.map(c => [c.t, c])); for (const c of d) mp.set(c.t, c);
  m.candles = [...mp.values()].sort((a, b) => a.t - b.t).slice(-5200); m.fetchAt = now();
}
async function loadDaily(coin) {
  const end = now(), d = mapC(await hlInfo({ type: "candleSnapshot", req: { coin, interval: "1d", startTime: end - 320 * DAY, endTime: end } }));
  if (d.length >= 200) M[coin].daily = toTyped(d);
}
async function pollMids() {
  const d = await hlInfo({ type: "allMids" }); let ok = 0;
  for (const c of COINS) { const p = parseFloat(d[c]); if (p > 0) { M[c].price = p; M[c].priceAt = now(); ok++; } }
  mktOk = ok > 0;
}
const closed = coin => M[coin].candles.filter(c => c.t + BAR <= now());
function failReason(coin) {
  const m = M[coin];
  if (now() - m.priceAt > 120000) return "prezzo non aggiornato";
  const cl = closed(coin); if (cl.length < 300) return "candele insufficienti";
  if (now() - (cl[cl.length - 1].t + BAR) > 2 * BAR) return "ultima candela troppo vecchia";
  if (!m.daily) return "candele giornaliere mancanti";
  return "";
}
// strategie con le opzioni dell'app (predefinite: long solo con volatilità bassa, squeeze long, short intelligenti) + modalità costanza per conto
const strats = steady => Core.STRATEGIES.filter(s => s.def).map(s => Object.assign({}, s, steady ? { ex: Object.assign({}, s.ex, { part: STEADY }) } : {}));
// segnali calcolati una volta per candela chiusa, uguali per tutti i conti
function signalsFor(coin) {
  const m = M[coin], cl = closed(coin); if (cl.length < 300) return null;
  const last = cl[cl.length - 1].t;
  if (m.sigBar !== last) { m.SIG = Core.buildSignals(toTyped(cl), strats(false), m.daily ? { daily: m.daily } : { volPct: new Float64Array(cl.length).fill(NaN) }); m.sigBar = last; m.sigN = cl.length; m.sigT = cl.map(c => c.t); }
  return m;
}

/* ================= conti ================= */
const ACC = new Map();   // id -> conto
const accFile = id => path.join(ACC_DIR, id + ".json");
function newSettings() { return { bot: false, risk: Core.BEST.cfg.risk, maxPos: 4, maxLev: 40, rsTop: true, steady: false, dailyLimit: true, daily: 5, capOn: true, cap: 1.5, adaptOn: true, riskHi: 1.5, riskLo: 0.75, capK: 2, capMax: 3, ctlOn: true, alarmOn: true, morningOn: true, alertsOn: true, exportOn: true, coins: Object.fromEntries(COINS.map(c => [c, true])), strats: Object.fromEntries(Core.STRATEGIES.filter(s => s.def).map(s => [s.id, true])), notify: true, weekly: true, limitOn: false, limWait: Core.LIMIT.waitMin }; }
function loadAccounts() { for (const f of fs.readdirSync(ACC_DIR)) if (f.endsWith(".json")) { const a = readJ(path.join(ACC_DIR, f), null); if (a && a.id) { a.set = Object.assign(newSettings(), a.set); a.real = Object.assign({ pos: {}, history: [], day: {}, pend: {}, limStats: { lim: 0, fb: 0, gone: 0 } }, a.real); a.lastBar = a.lastBar || {}; if (a.userStopped == null) a.userStopped = !a.set.bot; if (a.set.bot && !a.botSince) { a.botSince = now(); a.botSinceApprox = true; } ACC.set(a.id, a); } } }
// i campi che iniziano con "_" sono solo in memoria (client, letture, stato del controllo e dell'allarme): non si salvano
const saveAcc = a => writeJ(accFile(a.id), Object.fromEntries(Object.entries(a).filter(([k]) => !k.startsWith("_"))));
const client = a => a._c || (a._c = new HLM.Client(a.net, a.address, a.key));
function alog(a, msg, notify) { slog(`[${a.name}] ${msg}`); a.log = [stamp() + "  " + msg, ...(a.log || [])].slice(0, 200); if (notify !== false && a.set.notify) tgSend(a.chatId, (a.net === "mainnet" ? "💶 " : "🧪 TESTNET · ") + msg); }

/* ---------- ordini veri (stessa logica dell'app) ---------- */
let queue = Promise.resolve();
const enqueue = fn => (queue = queue.then(fn).catch(e => slog("errore: " + e.message)));
// Piano B: saldo realizzato (conto senza i guadagni/perdite delle posizioni aperte) e suo massimo storico
const realizedOf = acc => acc.equity - Object.values(acc.positions || {}).reduce((x, p) => x + (+p.unrealizedPnl || 0), 0);
function trackHwm(a, acc) { const r = realizedOf(acc); if (!(r > 0)) return r; if (!(a.real.hwm >= r)) { a.real.hwm = r; saveAcc(a); } return r; }
function adaptNow(a, acc) {
  if (!a.set.adaptOn) return null;
  const r = trackHwm(a, acc), s = a.set;
  return Object.assign(Core.adaptRisk({ balance: r, peak: a.real.hwm }, { hi: s.riskHi, lo: s.riskLo, k: s.capK, max: s.capMax }), { realized: r, hwm: a.real.hwm });
}
// la configurazione del conto è ancora "PastaBank v1"?
function presetDiff(st) {
  const P = Core.PRESET, d = [];
  if (COINS.some(c => !!st.coins[c] !== P.coins.includes(c))) d.push("monete");
  if (Object.keys(st.strats).some(k => !!st.strats[k] !== P.strats.includes(k)) || P.strats.some(k => !st.strats[k])) d.push("strategie");
  if (!st.rsTop) d.push("solo le 2 più forti");
  if (st.steady) d.push("costanza");
  if (!st.adaptOn || st.riskHi !== P.adapt.hi || st.riskLo !== P.adapt.lo || st.capK !== P.adapt.k || st.capMax !== P.adapt.max) d.push("rischio adattivo");
  if (st.maxPos !== P.maxPos || st.maxLev !== P.maxLev) d.push("posizioni/leva");
  return d;
}
const presetTxt = st => { const d = presetDiff(st); return d.length ? `${Core.presetLabel()} MODIFICATA (diversa in: ${d.join(", ")} · /pastabank per ripristinarla)` : `◆ ${Core.presetLabel()} (strategia congelata)`; };
function applyPreset(st) { const P = Core.PRESET; st.coins = Object.fromEntries(COINS.map(c => [c, P.coins.includes(c)])); st.strats = Object.fromEntries(Object.keys(st.strats).concat(P.strats).map(k => [k, P.strats.includes(k)])); Object.assign(st, { rsTop: P.rsTop, steady: false, adaptOn: true, riskHi: P.adapt.hi, riskLo: P.adapt.lo, capK: P.adapt.k, capMax: P.adapt.max, risk: P.risk, capOn: true, cap: P.cap, maxPos: P.maxPos, maxLev: P.maxLev }); }
const adaptTxt = (a, ad) => ad ? `${ad.high ? "AI MASSIMI" : "sotto il massimo"} → rischio ${ad.risk}% · tetto ${+ad.cap.toFixed(2)}% (saldo realizzato ${usd2(ad.realized)}, massimo ${usd2(ad.hwm)})` : "spento";
async function refreshAcc(a) {
  const c = client(a);
  const [acc, orders, mids] = await Promise.all([c.account(), c.openOrders(), c.mids()]);
  a._w = { acc, orders, mids: mids || {}, at: now() };
  // Correzione del 3 nov 2026: con l'account unificato il conto prima era contato due volte (USDC spot + perp).
  // Una volta sola, per questi conti, il massimo del piano B e l'inizio della giornata ripartono dal valore giusto.
  if (acc.unified && a.real.fixUnified !== 1) {
    const old = a.real.hwm;
    a.real.fixUnified = 1; a.real.hwm = realizedOf(acc); a.real.day = { key: todayKey(), startEq: acc.equity, locked: "" }; saveAcc(a);
    alog(a, `Conto corretto: con l'account unificato di Hyperliquid gli USDC venivano contati due volte. Valore giusto ${usd2(acc.equity)}${old ? " (massimo di prima " + usd2(old) + ")" : ""}; massimo e inizio giornata ripartono da qui.`);
  }
  trackHwm(a, acc);
  const k = todayKey();
  if (a.real.day.key !== k) a.real.day = { key: k, startEq: acc.equity, locked: "" };
  if (a.set.dailyLimit && a.real.day.locked !== k && a.real.day.startEq > 0 && acc.equity < a.real.day.startEq * (1 - a.set.daily / 100)) {
    a.real.day.locked = k; alog(a, `Perdita di oggi oltre il ${a.set.daily}%: niente nuovi ordini fino a domani (UTC).`);
  }
  return a._w;
}
const stopOrders = (a, coin) => (a._w ? a._w.orders : []).filter(o => o.coin === coin && o.isTrigger && o.reduceOnly);
const midOf = (a, coin) => parseFloat((a._w && a._w.mids[coin]) || 0) || M[coin].price;
async function pnlSince(a, coin, t) { try { const f = await client(a).fills(t - 60000); let p = 0, fee = 0; for (const x of f) if (x.coin === coin) { p += +x.closedPnl || 0; fee += +x.fee || 0; } return p - fee; } catch (e) { return NaN; } }
async function recordClose(a, coin, why) {
  const P = a.real.pos[coin]; if (!P) return;
  const pnl = await pnlSince(a, coin, P.opened);
  a.real.history.push({ coin, strat: P.strat, side: P.side, entry: P.entry, size: P.size, opened: P.opened, closed: now(), why, pnl });
  a.real.history = a.real.history.slice(-500);
  delete a.real.pos[coin]; saveAcc(a);
  alog(a, `${coin} · chiuso ${P.side > 0 ? "LONG" : "SHORT"} · ${stratName(P.strat)} · ${why}${isNaN(pnl) ? "" : ": " + sgn(pnl)}`);
}
/* Entrata con ordine limite: ordine eseguito → posizione del bot; scaduto (o bot fermato) → annullo il resto,
   piano B a mercato se il bot può ancora entrare, e lo stop nuovo sulla posizione intera prima di togliere i vecchi. */
async function managePend(a) {
  const w = a._w; if (!w) return;
  for (const coin of Object.keys(a.real.pend || {})) {
    const Q = a.real.pend[coin], c = client(a), open = (w.orders || []).some(o => o.oid === Q.oid), pos = w.acc.positions[coin];
    const record = (p, how) => {
      const s = Core.STRATEGIES.find(x => x.id === Q.strat) || { ex: {} }, ex = a.set.steady ? Object.assign({}, s.ex, { part: STEADY }) : s.ex, entry = +p.entryPx, size = Math.abs(+p.szi);
      a.real.pos[coin] = { coin, strat: Q.strat, side: Q.side, size, entry, sl: Q.sl, slD: Math.abs(entry - Q.sl), lev: Q.lev, beDone: false, ex, opened: Q.placed, entryBy: how };
      delete a.real.pend[coin]; saveAcc(a);
      alog(a, `${coin} · aperto ${Q.side > 0 ? "LONG" : "SHORT"} · ${stratName(Q.strat)} · ${how} · ${size} ${coin} a ${usd(entry)} · leva ${Q.lev}x · stop ${usd(Q.sl)} · rischio ${(+Q.riskPct || 0).toFixed(2)}%`);
    };
    if (!open && pos && +pos.szi * Q.side > 0 && Math.abs(+pos.szi) >= Q.sz * 0.999) { a.real.limStats.lim++; record(pos, "ordine limite eseguito"); continue; }
    if (open && now() < Q.until && !Q.stop) continue;
    try { if (open) await c.cancel(coin, Q.oid); } catch (e) {}
    await new Promise(r => setTimeout(r, 1200));
    try {
      const acc = await c.account(), p = acc.positions[coin], done = p && +p.szi * Q.side > 0 ? Math.abs(+p.szi) : 0;
      const meta = await c.coinMeta(coin), mid = await c.mid(coin), rest = HLM.roundSz(Q.sz - done, meta.szDecimals), why = Q.stop || blocked(a, coin);
      if (rest * mid >= 10.5 && !why) {
        const m = await c.coinMeta(coin), px = Q.side > 0 ? mid * (1 + SLIP_REAL) : mid * (1 - SLIP_REAL);
        const d = await c.exchange({ type: "order", orders: [c.wire(m, Q.side > 0, px, rest, false, { limit: { tif: "Ioc" } })], grouping: "na" }), st = (d.statuses || [])[0] || {};
        if (st.error) throw new Error(st.error);
        alog(a, `${coin}: piano B, ${done ? "completati" : "entrati"} a mercato ${rest} ${coin}${st.filled ? " a " + usd(+st.filled.avgPx) : ""}.`, false);
      } else if (!done) alog(a, `${coin}: ordine limite ${Q.stop ? "annullato" : "scaduto"}${why ? ", piano B non inviato (" + why + ")" : ""}.`, false);
      await new Promise(r => setTimeout(r, 1200));
      const a2 = await c.account(), p2 = a2.positions[coin];
      if (p2 && +p2.szi * Q.side > 0) {
        const keep = await c.placeStop(coin, Q.side < 0, Math.abs(+p2.szi), Q.sl);
        for (const o of await c.openOrders()) if (o.coin === coin && o.isTrigger && o.reduceOnly && o.oid !== keep) { try { await c.cancel(coin, o.oid); } catch (e) {} }
        if (done) a.real.limStats.lim++; else a.real.limStats.fb++;
        record(p2, done && rest * mid >= 10.5 && !why ? "ordine limite in parte + piano B" : done ? "ordine limite in parte" : "piano B a mercato");
      } else { await c.cancelTriggers(coin); a.real.limStats.gone++; delete a.real.pend[coin]; saveAcc(a); }
    } catch (e) { alog(a, `${coin}: gestione dell'ordine limite non riuscita (${e.message}), riprovo tra 15 secondi.`); }
  }
}
// annulla gli ordini limite in attesa (bot fermato, chiusura di tutto, scollegamento): niente piano B
const stopPend = a => { for (const Q of Object.values(a.real.pend || {})) Q.stop = "ordine annullato"; };
async function manageAcc(a) {
  if (!a._w) return;
  // dopo un ordine limite eseguito o un piano B il conto letto prima è vecchio: lo rileggo, altrimenti la posizione nuova sembrerebbe chiusa
  if (Object.keys(a.real.pend || {}).length) { await managePend(a); await refreshAcc(a); }
  const w = a._w;
  // posizioni sparite dall'exchange = chiuse da stop o obiettivo
  for (const coin of Object.keys(a.real.pos)) {
    const P = a.real.pos[coin], pos = w.acc.positions[coin];
    if (!pos) { await recordClose(a, coin, "chiusa dall'exchange (stop o obiettivo)"); try { await client(a).cancelTriggers(coin); } catch (e) {} continue; }
    const side = +pos.szi > 0 ? 1 : -1; if (side !== P.side) continue;
    const meta = await client(a).coinMeta(coin), mid = midOf(a, coin);
    P.size = Math.abs(+pos.szi);
    if (!stopOrders(a, coin).length && now() - P.opened > 4000) {
      try { await client(a).placeStop(coin, P.side < 0, P.size, P.sl); alog(a, `${coin}: stop mancante, rimesso sull'exchange.`); }
      catch (e) { alog(a, `${coin}: stop non impostabile (${e.message}), chiudo per sicurezza.`); await doClose(a, coin, "sicurezza: stop non attivo"); continue; }
    }
    if (P.ex && P.ex.part && !P.partDone && mid && (P.side > 0 ? mid >= P.entry + P.ex.part.r * P.slD : mid <= P.entry - P.ex.part.r * P.slD)) {
      const sz = HLM.roundSz(P.size * P.ex.part.frac, meta.szDecimals);
      try {
        if (sz * mid >= 10.5 && P.size - sz > 0) { await client(a).reduceMarket(coin, P.side < 0, sz, SLIP_REAL); P.size = +(P.size - sz).toFixed(meta.szDecimals); alog(a, `${coin}: uscita parziale, chiusi ${sz} ${coin}.`); }
        P.partDone = true;
        const be = P.entry * (1 + P.side * 2 * Core.DEFAULTS.fee), old = stopOrders(a, coin);
        await client(a).placeStop(coin, P.side < 0, P.size, be); for (const o of old) { try { await client(a).cancel(coin, o.oid); } catch (e) {} }
        P.beDone = true; P.sl = be; saveAcc(a); alog(a, `${coin}: stop della parte rimasta a pareggio.`);
      } catch (e) { alog(a, `${coin}: uscita parziale non riuscita, riprovo: ${e.message}`, false); }
    }
  }
}
/* ================= controllo con Hyperliquid =================
   Confronta quello che il bot crede di avere con il conto vero. Corregge da solo solo i casi sicuri
   (stop doppi, stop con la quantità sbagliata, stop rimasti senza posizione); nei casi dubbi blocca le
   nuove entrate e avvisa, senza indovinare. Un problema conta solo se si ripresenta in 2 letture di fila. */
const side$ = v => v > 0 ? "LONG" : "SHORT";
async function reconcile(a) {
  const w = a._w; if (!w) return;
  if (!a.set.ctlOn) { a._ctl = { off: true, lock: false, issues: [], at: now() }; a._startOk = true; return; }
  const pos = w.acc.positions || {}, ords = w.orders || [], iss = [], fix = [];
  for (const [coin, p] of Object.entries(pos)) {
    const szi = +p.szi, side = szi > 0 ? 1 : -1, size = Math.abs(szi), P = a.real.pos[coin], st = stopOrders(a, coin), mark = midOf(a, coin), liq = +p.liquidationPx || 0;
    if (!P && a.real.pend && a.real.pend[coin]) continue; // ordine limite del bot in corso di esecuzione
    if (!P) { iss.push({ k: "orfana:" + coin, t: `${coin}: posizione ${side$(side)} ${size} sul conto che il bot non conosce (${st.length ? "ha uno stop" : "SENZA stop"}). Scrivi /adotta ${coin} per farla gestire al bot, oppure chiudila tu.` }); continue; }
    if (side !== P.side) { iss.push({ k: "verso:" + coin, t: `${coin}: sul conto è ${side$(side)}, ma il bot l'aveva registrata ${side$(P.side)}.` }); continue; }
    if (st.length > 1) { const best = st.slice().sort((x, y) => Math.abs(+x.triggerPx - P.sl) - Math.abs(+y.triggerPx - P.sl))[0]; fix.push({ k: "doppi:" + coin, t: `${coin}: ${st.length} stop sull'exchange, ne tengo uno solo`, run: async () => { for (const o of st) if (o.oid !== best.oid) await client(a).cancel(coin, o.oid); } }); }
    else if (st.length === 1 && +st[0].sz > 0 && Math.abs(+st[0].sz - size) > size * 0.002 + 1e-12) { const old = st[0]; fix.push({ k: "taglia:" + coin, t: `${coin}: lo stop copriva ${+old.sz} invece di ${size}, rimesso della quantità giusta allo stesso prezzo`, run: async () => { await client(a).placeStop(coin, P.side < 0, size, +old.triggerPx); await client(a).cancel(coin, old.oid); P.size = size; saveAcc(a); } }); }
    for (const o of st) { const tp = +o.triggerPx;
      if (mark && (side > 0 ? tp >= mark * 1.001 : tp <= mark * 0.999)) iss.push({ k: "lato:" + coin, t: `${coin}: lo stop a ${usd(tp)} è dalla parte sbagliata del prezzo (${usd(mark)}).` });
      if (liq && (side > 0 ? tp <= liq : tp >= liq)) iss.push({ k: "liq:" + coin, t: `${coin}: lo stop a ${usd(tp)} è oltre la liquidazione (${usd(liq)}): scatterebbe dopo.` }); }
  }
  for (const o of ords) {
    if (a.real.pend && a.real.pend[o.coin]) continue; // ordine limite del bot e il suo stop agganciato
    if (o.isTrigger && o.reduceOnly) { if (!pos[o.coin]) fix.push({ k: "stoporfano:" + o.oid, t: `${o.coin}: stop rimasto senza posizione, tolto`, run: async () => { await client(a).cancel(o.coin, o.oid); } }); continue; }
    iss.push({ k: "ordine:" + o.oid, t: `${o.coin}: c'è un ordine aperto (${o.orderType || "limite"} ${o.side === "B" ? "acquisto" : "vendita"} ${o.sz}) che il bot non ha messo.` });
  }
  // conta le ripetizioni: si agisce solo su ciò che si vede in 2 letture di fila (le operazioni appena aperte hanno qualche secondo di assestamento)
  const seen = a._ctlSeen || {}, next = {};
  for (const x of [...iss, ...fix]) next[x.k] = (seen[x.k] || 0) + 1;
  a._ctlSeen = next;
  for (const f of fix) if (next[f.k] === 2) { try { await f.run(); alog(a, "Controllo: " + f.t + ".", false); tgSend(a.chatId, "🔧 Controllo: " + f.t + "."); } catch (e) { alog(a, `Controllo: correzione non riuscita (${f.t}): ${e.message}`, false); } }
  const ign = a._ctlIgnore || new Set(); for (const k of [...ign]) if (!next[k]) ign.delete(k); a._ctlIgnore = ign;
  const firm = iss.filter(x => next[x.k] >= 2), active = firm.filter(x => !ign.has(x.k));
  const prev = a._ctl || {}, lock = active.length > 0;
  for (const x of active) if (!(prev.keys || []).includes(x.k)) tgSend(a.chatId, `⚠ Controllo con Hyperliquid: ${x.t}\nNiente nuove entrate finché non torna coerente (le posizioni restano protette dagli stop). /controllo per i dettagli · /sblocca se è tutto voluto.`);
  if (prev.lock && !lock) tgSend(a.chatId, "✅ Controllo con Hyperliquid: tutto di nuovo coerente, il bot riprende le entrate.");
  a._ctl = { off: false, lock, issues: firm.map(x => ({ t: x.t, ignored: ign.has(x.k) })), keys: active.map(x => x.k), at: now() };
  if (!a._startOk && (iss.length === 0 || (a._ctlChecks = (a._ctlChecks || 0) + 1) >= 2)) { a._startOk = true; if (!lock) slog(`[${a.name}] controllo iniziale superato.`); }
}
const ctlTxt = a => !a.set.ctlOn ? "spento" : !a._ctl ? "in attesa della prima lettura del conto" : a._ctl.lock ? "⚠ BLOCCO: " + a._ctl.issues.filter(x => !x.ignored).map(x => x.t).join(" · ") : a._ctl.issues.length ? "✅ coerente (con differenze che hai accettato: " + a._ctl.issues.length + ")" : "✅ coerente";

/* ================= allarme Telegram e messaggio del mattino ================= */
function alarmTick() {
  const t = now();
  for (const a of ACC.values()) {
    if (!a.chatId) continue;
    const s = a.set, al = a._al || (a._al = {});
    const conds = {};
    if (s.alarmOn) {
      if (!s.bot && a.userStopped === false) conds.bot = "⚠ Il bot risulta FERMO ma non l'hai fermato tu. Scrivi /avvia per riaccenderlo.";
      if (a.key && s.bot) { const at = a._w ? a._w.at : 0; if (t - Math.max(at, BOOT) > 10 * 60000) conds.acc = `⚠ Non riesco a leggere il conto Hyperliquid da ${Math.round((t - Math.max(at, BOOT)) / 60000)} minuti. Nessuna nuova entrata finché non torna (le posizioni restano protette dagli stop).`; }
      if (s.bot) { const fr = coinsOn(a).map(c => failReason(c)).filter(Boolean); if (fr.length) conds.mkt = `⚠ Dati di mercato assenti o vecchi (${fr[0]}). Nessuna nuova entrata finché non tornano.`; }
    }
    for (const k of ["bot", "acc", "mkt"]) {
      const st = al[k] || (al[k] = { since: 0, sent: 0 });
      if (conds[k]) { if (!st.since) st.since = t; const wait = k === "acc" ? 0 : 10 * 60000; if (t - st.since >= wait && t - st.sent >= 3600000) { st.sent = t; tgSend(a.chatId, conds[k]); } }
      else { if (st.sent) tgSend(a.chatId, "✅ Tutto di nuovo normale: " + (k === "bot" ? "il bot è acceso." : k === "acc" ? "il conto si legge di nuovo." : "i dati di mercato arrivano regolari.")); st.since = 0; st.sent = 0; }
    }
    // messaggio del mattino (9:00 ora italiana)
    if (s.morningOn) { const d = new Date(t + romeOffset(t)), key = d.toISOString().slice(0, 10);
      if (d.getUTCHours() >= 9 && a.lastMorning !== key) { a.lastMorning = key; saveAcc(a);
        const w = a._w, eq = w ? w.acc.equity : null, ad = w ? adaptNow(a, w.acc) : null, ps = w ? Object.keys(w.acc.positions) : [];
        tgSend(a.chatId, `☀️ Buongiorno · CashMkr ${s.bot ? "ATTIVO" : "FERMO"} · ${presetTxt(s)}\nConto: ${eq != null ? usd2(eq) : "non leggibile"}${eq != null && a.real.day.startEq ? " · oggi " + sgn(eq - a.real.day.startEq) : ""}\nPosizioni: ${ps.join(", ") || "nessuna"}\nRischio: ${ad ? (ad.high ? "ai massimi " : "sotto il massimo ") + ad.risk + "%" : s.risk + "%"}\nControllo: ${ctlTxt(a)}\nSe una mattina questo messaggio non arriva, il server è spento: entra e riavvialo.`); } }
  }
}
/* ================= allerte gravi: solo motivi veri per fermare e ritirare =================
   1) USDC (la moneta del conto Hyperliquid) sotto 0,97 $ per 15 minuti, confermato da Kraken E Bitstamp;
   2) Hyperliquid (o il suo ponte su Arbitrum) attaccato, prelievi bloccati, insolvente: almeno 2 testate su 3 entro 3 ore.
   Nessun ordine automatico: solo un messaggio Telegram. Interruttore per conto: /opzione allerte on|off. */
const ALSRC = Object.assign({
  kraken: "https://api.kraken.com/0/public/Ticker?pair=USDCUSD",
  bitstamp: "https://www.bitstamp.net/api/v2/ticker/usdcusd/",
  feeds: { "CoinDesk": "https://www.coindesk.com/arc/outboundfeeds/rss/", "Cointelegraph": "https://cointelegraph.com/rss", "The Block": "https://www.theblock.co/rss.xml" },
}, JSON.parse(process.env.CASHMKR_ALERT_SRC || "{}"));
const AL_FILE = path.join(DIR, "allerte.json"), alSaved = readJ(AL_FILE, {});
const AL = { usdc: { k: NaN, b: NaN, at: 0, below: 0, fired: !!alSaved.usdcFired, err: {} }, news: { at: 0, hits: [], fired: alSaved.newsFired || 0, last: null, ok: {} }, lastSent: alSaved.lastSent || null };
const alSave = () => { try { writeJ(AL_FILE, { usdcFired: AL.usdc.fired, newsFired: AL.news.fired, lastSent: AL.lastSent }); } catch (e) {} };
const ALERT_USDC = 0.97, ALERT_USDC_MIN = 15 * 60000, ALERT_NEWS_WIN = 3 * 3600000;
async function getJ(u) { const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 10000); try { const r = await fetch(u, { signal: ctl.signal, headers: { "User-Agent": "CashMkr-Server" } }); if (!r.ok) throw new Error("HTTP " + r.status); return await r.text(); } finally { clearTimeout(to); } }
// titoli che contano: nominano Hyperliquid (o il ponte su Arbitrum) E un pericolo grave per i fondi
const AL_SUBJ = /hyperliquid|hyperevm/i, AL_BRIDGE = /arbitrum[^.]{0,40}bridge|bridge[^.]{0,40}arbitrum/i;
const AL_BAD = /\b(hack(?:ed|er|ers|s)?|exploit(?:ed|s)?|drain(?:ed|s)?|stolen|theft|breach(?:ed)?|compromised|insolven(?:t|cy)|bankrupt(?:cy)?|collapse[sd]?|(?:halt|pause|suspend|freeze|froze|frozen|block)(?:s|ed|es)?\s+(?:all\s+)?(?:withdrawals?|deposits?|bridge)|withdrawals?\s+(?:halted|paused|suspended|frozen|blocked)|funds?\s+at\s+risk)\b/i;
const AL_NOT = /\b(denies|denied|rumou?r|fake|false alarm|no funds (?:lost|at risk)|recover(?:ed|s)|returns? (?:the )?funds|bug bounty|white ?hat|resumes?|reopens?|simulat|what if)\b/i;
const unx = t => String(t || "").replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1").replace(/<[^>]+>/g, "").replace(/&amp;/g, "&").replace(/&#39;|&apos;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, "<").replace(/&gt;/g, ">").trim();
function parseRss(xml) { const out = []; for (const m of String(xml).matchAll(/<item[\s>][\s\S]*?<\/item>/gi)) { const it = m[0], g = tag => { const x = it.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, "i")); return x ? unx(x[1]) : ""; }; out.push({ title: g("title"), link: g("link") || g("guid"), t: Date.parse(g("pubDate")) || 0 }); } return out; }
const alertHit = title => (AL_SUBJ.test(title) || AL_BRIDGE.test(title)) && AL_BAD.test(title) && !AL_NOT.test(title);
function alertMsg(ev) {
  const head = (ev.test ? "🧪 PROVA · " : "") + "🚨 MOTIVO PER FERMARE E RITIRARE";
  const todo = "Cosa fare:\n1) /ferma — niente nuove entrate\n2) /chiudi SI — chiude tutte le posizioni\n3) ritira i fondi dal sito di Hyperliquid, se i prelievi funzionano";
  if (ev.kind === "usdc") return `${head}\nUSDC, la moneta del tuo conto Hyperliquid, ha perso la parità: ${pxU(ev.k)} su Kraken e ${pxU(ev.b)} su Bitstamp, sotto 0,97 $ da ${Math.round(ev.mins)} minuti.\nIl valore del conto scende con USDC, qualunque cosa faccia il bot.\n\n${todo}`;
  const srcs = [...new Set(ev.items.map(i => i.src))];
  return `${head}\nHyperliquid in pericolo: lo riportano ${srcs.join(", ")}.\n${ev.items.slice(0, 4).map(i => `• ${i.src} (${stampRome(i.t)}): ${i.title}\n  ${i.link}`).join("\n")}\n\n${todo}\n\nPrima di agire apri almeno un link e verifica.`;
}
const pxU = v => "$" + v.toFixed(4).replace(".", ",");
const stampRome = t => new Date(t + romeOffset(t)).toISOString().slice(11, 16);
function alertSend(ev) {
  AL.lastSent = { t: now(), kind: ev.kind }; setTimeout(alSave, 0);
  const msg = alertMsg(ev); slog("ALLERTA: " + msg.split("\n")[1]);
  for (const a of ACC.values()) if (a.chatId && a.set.alertsOn) { tgSend(a.chatId, msg); alog(a, "Allerta grave inviata: " + msg.split("\n")[1], false); }
}
function alertBack(txt) { for (const a of ACC.values()) if (a.chatId && a.set.alertsOn) tgSend(a.chatId, "✅ Rientrato: " + txt); }
async function alertUsdc() {
  const U = AL.usdc, t = now();
  const [k, b] = await Promise.all([
    getJ(ALSRC.kraken).then(x => { const j = JSON.parse(x), r = j.result && Object.values(j.result)[0]; U.err.kraken = ""; return +(r && r.c && r.c[0]); }).catch(e => { U.err.kraken = e.message; return NaN; }),
    getJ(ALSRC.bitstamp).then(x => { U.err.bitstamp = ""; return +JSON.parse(x).last; }).catch(e => { U.err.bitstamp = e.message; return NaN; }),
  ]);
  U.k = k; U.b = b; U.at = t;
  const low = k > 0 && b > 0 && k < ALERT_USDC && b < ALERT_USDC;      // tutte e due le fonti d'accordo
  if (low) { if (!U.below) U.below = t; if (!U.fired && t - U.below >= ALERT_USDC_MIN) { U.fired = true; alertSend({ kind: "usdc", k, b, mins: (t - U.below) / 60000 }); } }
  else if (k > 0 && b > 0) { if (U.fired && k >= 0.985 && b >= 0.985) { U.fired = false; alSave(); alertBack(`USDC è tornato vicino a 1 $ (${pxU(k)} Kraken, ${pxU(b)} Bitstamp).`); } if (!U.fired) U.below = 0; }
}
async function alertNews() {
  const N = AL.news, t = now();
  await Promise.all(Object.entries(ALSRC.feeds).map(async ([src, u]) => {
    try { const items = parseRss(await getJ(u)); N.ok[src] = { at: t, n: items.length };
      for (const it of items) { const ti = it.t || t; if (t - ti > ALERT_NEWS_WIN || !alertHit(it.title)) continue; if (!N.hits.some(h => h.src === src && h.title === it.title)) N.hits.push({ src, title: it.title, link: it.link, t: ti }); }
    } catch (e) { N.ok[src] = { at: (N.ok[src] || {}).at || 0, err: e.message }; }
  }));
  N.hits = N.hits.filter(h => t - h.t <= ALERT_NEWS_WIN); N.at = t;
  const srcs = new Set(N.hits.map(h => h.src));
  if (srcs.size >= 2 && t - N.fired > 24 * 3600000) { N.fired = t; N.last = { t, items: N.hits.slice() }; alertSend({ kind: "hl", items: N.hits.slice().sort((x, y) => x.t - y.t) }); }
}
let alertBusy = false, alertNewsAt = 0;
async function alertTick() {
  if (alertBusy || ![...ACC.values()].some(a => a.chatId && a.set.alertsOn)) return;
  alertBusy = true;
  try { await alertUsdc(); if (now() - alertNewsAt >= 5 * 60000) { alertNewsAt = now(); await alertNews(); } } finally { alertBusy = false; }
}
function alertStatus(a) {
  const U = AL.usdc, N = AL.news, fmt = v => v > 0 ? pxU(v) : "non letto";
  const feeds = Object.keys(ALSRC.feeds).map(s => { const o = N.ok[s]; return `${s}: ${!o ? "non ancora letta" : o.err ? "non raggiungibile (" + o.err + ")" : "letta " + stampRome(o.at)}`; }).join("\n");
  return `Allerte gravi: ${a.set.alertsOn ? "ACCESE" : "SPENTE (/opzione allerte on)"}\n\nUSDC: ${fmt(U.k)} Kraken · ${fmt(U.b)} Bitstamp${U.at ? " (" + stampRome(U.at) + ")" : ""} · ${U.fired ? "🚨 SOTTO LA PARITÀ" : U.below ? "sotto 0,97 da " + Math.round((now() - U.below) / 60000) + " min, in osservazione" : "in ordine"}\n\nTestate (Hyperliquid in pericolo, servono 2 su 3):\n${feeds}\nTitoli sospetti nelle ultime 3 ore: ${N.hits.length ? N.hits.map(h => h.src + ": " + h.title).join(" | ") : "nessuno"}\n\nUltima allerta inviata: ${AL.lastSent ? stampRome(AL.lastSent.t) + " (" + (AL.lastSent.kind === "usdc" ? "USDC" : "Hyperliquid") + ")" : "nessuna"}\nIl bot non si ferma mai da solo: decidi tu.`;
}
async function doClose(a, coin, why) {
  try { await client(a).closeMarket(coin, SLIP_REAL); await new Promise(r => setTimeout(r, 1500)); await recordClose(a, coin, why); }
  catch (e) { alog(a, `${coin}: chiusura non riuscita: ${e.message}`); }
}
function blocked(a, coin, t) {
  if (!a.set.bot) return "bot fermo";
  if (!a.key) return "chiave mancante";
  if (!a.set.coins[coin]) return coin + " spenta";
  const fr = failReason(coin); if (fr) return "blocco di sicurezza (" + fr + ")";
  if (a.set.dailyLimit && a.real.day.locked === todayKey()) return "perdita giornaliera massima raggiunta";
  if (a.set.ctlOn && !a._startOk) return "controllo iniziale con Hyperliquid non ancora fatto";
  if (a.set.ctlOn && a._ctl && a._ctl.lock) return "blocco del controllo con Hyperliquid (" + (a._ctl.issues.find(x => !x.ignored) || {}).t + ")";
  return "";
}
const coinsOn = a => COINS.filter(c => a.set.coins[c]);
const ranks = (a, t) => Core.rsRanks(Object.fromEntries(coinsOn(a).map(c => [c, M[c].daily])), t, Core.RS.lbs);
async function doOpen(a, coin, s, side, slPct) {
  try {
    const c = client(a), [acc, mid, meta] = await Promise.all([c.account(), c.mid(coin), c.coinMeta(coin)]);
    if (acc.positions[coin] || a.real.pos[coin]) return alog(a, `${coin}: segnale ${s.title} non eseguito, c'è già una posizione su ${coin}.`, false);
    if (a.real.pend[coin]) return alog(a, `${coin}: segnale ${s.title} non eseguito, c'è già un ordine limite in attesa su ${coin}.`, false);
    const nBot = Object.keys(a.real.pos).length + Object.keys(a.real.pend).length; if (nBot >= a.set.maxPos) return alog(a, `${coin}: segnale non eseguito, già ${nBot} posizioni (limite ${a.set.maxPos}).`, false);
    const lev = Math.max(1, Math.min(Math.floor(1 / (slPct * 1.5 + Core.DEFAULTS.mmr)), meta.maxLeverage, a.set.maxLev));
    const ad = adaptNow(a, acc);
    let riskPct = ad ? ad.risk : a.set.risk;
    const baseR = riskPct, capPct = ad ? ad.cap : (a.set.capOn ? a.set.cap : 0);
    if (capPct) {
      const used = Core.openRisk(Object.values(a.real.pos), Core.DEFAULTS.fee) / acc.equity * 100, left = capPct - used;
      if (left < baseR * 0.1) return alog(a, `${coin}: segnale ${s.title} non eseguito, tetto di rischio totale raggiunto (${used.toFixed(2)}% già a rischio, tetto ${+capPct.toFixed(2)}%).`);
      if (left < riskPct) { riskPct = left; alog(a, `${coin}: rischio ridotto a ${left.toFixed(2)}% per restare nel tetto totale del ${+capPct.toFixed(2)}%.`, false); }
    }
    let notional = acc.equity * riskPct / 100 / (slPct + 2 * Core.DEFAULTS.fee + 0.0005);
    if (notional / lev > acc.available * 0.95) notional = acc.available * 0.95 * lev;
    const sz = HLM.roundSz(notional / mid, meta.szDecimals);
    if (sz * mid < 10.5) return alog(a, `${coin}: ordine non inviato, valore ${usd2(sz * mid)} sotto il minimo di 10 $ (conto ${usd2(acc.equity)}).`);
    const sl = mid * (1 - side * slPct);
    await c.setLeverage(coin, lev);
    if (a.set.limitOn) {
      // Entrata con ordine limite "solo maker" al miglior prezzo del libro, con lo stop agganciato; il piano B lo gestisce managePend
      const bk = await c.book(coin), lim = side > 0 ? bk.bid : bk.ask, ls = await c.openLimitProtected(coin, side > 0, sz, lim, sl), r0 = ls[0] || {};
      if (r0.resting) {
        a.real.pend[coin] = { oid: r0.resting.oid, coin, strat: s.id, side, sz, lim, sl, lev, riskPct, placed: now(), until: now() + (a.set.limWait || Core.LIMIT.waitMin) * 60000 };
        saveAcc(a);
        return alog(a, `${coin} · ordine limite ${side > 0 ? "LONG" : "SHORT"} a ${usd(lim)} · ${s.title} · ${sz} ${coin} · stop ${usd(sl)} agganciato · attesa ${a.set.limWait} min, poi a mercato`, false);
      }
      alog(a, `${coin}: ordine limite non accettato (${r0.error || "eseguibile subito"}), entro a mercato.`, false);
    }
    const st = await c.openProtected(coin, side > 0, sz, mid, sl, 0, SLIP_REAL), f = st[0] && st[0].filled;
    if (!f) return alog(a, `${coin}: ordine rifiutato: ` + ((st[0] && st[0].error) || JSON.stringify(st[0])));
    const entry = +f.avgPx, size = +f.totalSz, ex = a.set.steady ? Object.assign({}, s.ex, { part: STEADY }) : s.ex;
    a.real.pos[coin] = { coin, strat: s.id, side, size, entry, sl, slD: Math.abs(entry - sl), lev, beDone: false, ex, opened: now(), entryBy: "a mercato" };
    saveAcc(a);
    alog(a, `${coin} · aperto ${side > 0 ? "LONG" : "SHORT"} · ${s.title} · ${size} ${coin} a ${usd(entry)} · leva ${lev}x · stop ${usd(sl)} · rischio ${riskPct.toFixed(2)}%`);
  } catch (e) { alog(a, `${coin}: errore nell'invio dell'ordine: ${e.message}`); }
}
// a ogni candela chiusa: uscite al segnale opposto e nuove entrate, per ogni conto
function onBar(coin) {
  const m = signalsFor(coin); if (!m) return;
  const i = m.sigN - 1, barT = m.sigT[i], live = now() - (barT + BAR) < 10 * 60000, SIG = m.SIG;
  for (const a of ACC.values()) {
    if ((a.lastBar[coin] || 0) >= barT) continue; a.lastBar[coin] = barT;
    if (!a.key) continue;
    const P = a.real.pos[coin];
    if (P && P.strat !== "manuale" && SIG[P.strat] && SIG[P.strat].raw[i] === -P.side) enqueue(() => doClose(a, coin, "Segnale opposto").then(() => refreshAcc(a)));
    if (!live) continue;
    for (const s of strats(a.set.steady)) {
      const x = SIG[s.id], d = x.sig[i]; if (!d || isNaN(x.A[i]) || !a.set.strats[s.id]) continue;
      const nm = `${coin} · segnale ${d > 0 ? "LONG" : "SHORT"} di ${s.title}`;
      const why = blocked(a, coin);
      if (why) { if (a.set.bot) alog(a, `${nm} ignorato: ${why}.`, false); continue; }
      const t = barT + BAR;
      if (s.smart) { const rw = Core.smartShortReason(ranks(a, t), coin, M.BTC.daily, t); if (rw) { alog(a, `${nm} ignorato: ${rw}.`, false); continue; } }
      else if (a.set.rsTop) { const r = ranks(a, t)[coin]; if (r == null || r >= Core.RS.top) { alog(a, `${nm} ignorato: ${coin} è ${r == null ? "?" : r + 1}ª in classifica, non tra le prime ${Core.RS.top}.`, false); continue; } }
      const slPct = s.ex.sl * x.A[i] / (M[coin].price || m.candles[m.candles.length - 1].c);
      enqueue(() => doOpen(a, coin, s, d, slPct).then(() => refreshAcc(a).catch(() => {})));
      break; // una posizione per moneta
    }
    saveAcc(a);
  }
}

/* ================= resoconto settimanale ================= */
// settimana da lunedì 00:00 (ora italiana) letta dagli eseguiti di Hyperliquid: include anche le operazioni chiuse a mano
const romeOffset = t => { const d = new Date(t); const s = d.toLocaleString("en-US", { timeZone: "Europe/Rome" }); return new Date(s).getTime() - new Date(d.toLocaleString("en-US", { timeZone: "UTC" })).getTime(); };
function weekStartRome(t) { const off = romeOffset(t), d = new Date(t + off); const wd = (d.getUTCDay() + 6) % 7; d.setUTCHours(0, 0, 0, 0); return d.getTime() - wd * DAY - off; }
async function weekReport(a, w0) {
  const w1 = w0 + 7 * DAY;
  let F = []; try { F = (await client(a).fills(w0)).filter(f => +f.time < w1); } catch (e) { return "Non riesco a leggere le operazioni da Hyperliquid: " + e.message; }
  const isClose = f => f.dir ? /^Close|>|Liquidat/i.test(f.dir) : Math.abs(+f.closedPnl || 0) > 0;
  const grp = arr => { const out = []; for (const f of arr.sort((x, y) => x.time - y.time)) { const g = out.find(o => o.coin === f.coin && Math.abs(f.time - o.last) < 120000); if (g) { g.pnl += (+f.closedPnl || 0) - (+f.fee || 0); g.last = +f.time; } else out.push({ coin: f.coin, last: +f.time, pnl: (+f.closedPnl || 0) - (+f.fee || 0) }); } return out; };
  const opens = grp(F.filter(f => !isClose(f))), closes = grp(F.filter(isClose)), tot = F.reduce((x, f) => x + (+f.closedPnl || 0) - (+f.fee || 0), 0), won = closes.filter(o => o.pnl > 0).length;
  const w = a._w, ps = w ? Object.entries(w.acc.positions) : [], un = ps.reduce((x, [, p]) => x + (+p.unrealizedPnl || 0), 0);
  const dd = t => new Date(t).toLocaleDateString("it-IT", { day: "2-digit", month: "2-digit", timeZone: "Europe/Rome" });
  return `📅 Settimana ${dd(w0)} → ${dd(w1 - 1)} · ${a.name} (${a.net})\nTotale: ${sgn(tot)}\nAperte ${opens.length} · chiuse ${closes.length} (vinte ${won}, perse ${closes.length - won})` +
    (closes.length ? "\n" + closes.map(o => `• ${new Date(o.last).toLocaleString("it-IT", { weekday: "short", hour: "2-digit", minute: "2-digit", timeZone: "Europe/Rome" })} ${o.coin}: ${sgn(o.pnl)}`).join("\n") : "") +
    `\n${ps.length ? "Ancora aperte: " + ps.map(([c, p]) => c + (+p.szi > 0 ? " long" : " short")).join(", ") + " · non realizzato " + sgn(un) : "Nessuna posizione aperta."}` + (w ? `\nConto: ${usd2(w.acc.equity)}` : "");
}
// domenica alle 20:00 (ora italiana) il riepilogo arriva da solo a chi ha l'opzione accesa
let lastWeekly = readJ(path.join(DIR, "settimanale.json"), {});
function weeklyTick() {
  const t = now(), off = romeOffset(t), d = new Date(t + off);
  if (d.getUTCDay() !== 0 || d.getUTCHours() < 20) return;
  const key = d.toISOString().slice(0, 10);
  for (const a of ACC.values()) if (a.set.weekly && a.chatId && lastWeekly[a.id] !== key) { lastWeekly[a.id] = key; writeJ(path.join(DIR, "settimanale.json"), lastWeekly); weekReport(a, weekStartRome(t)).then(m => tgSend(a.chatId, m)); }
}

/* ================= Telegram ================= */
// invio di un file (sendDocument, multipart)
async function tgDoc(chatId, filename, text, caption) {
  if (!CFG.telegramToken) return null;
  try { const fd = new FormData(); fd.append("chat_id", String(chatId)); if (caption) fd.append("caption", caption); fd.append("document", new Blob([text], { type: "text/csv" }), filename);
    const r = await fetch(`${TG}/bot${CFG.telegramToken}/sendDocument`, { method: "POST", body: fd }); return await r.json(); }
  catch (e) { slog("Telegram: invio file non riuscito: " + e.message); return null; }
}
async function tg(method, body) {
  if (!CFG.telegramToken) return null;
  try { const r = await fetch(`${TG}/bot${CFG.telegramToken}/${method}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) }); return await r.json(); }
  catch (e) { slog("Telegram non raggiungibile: " + e.message); return null; }
}
const KB = { keyboard: [[{ text: "/stato" }, { text: "/posizioni" }, { text: "/settimana" }], [{ text: "/avvia" }, { text: "/ferma" }], [{ text: "/classifica" }, { text: "/aiuto" }]], resize_keyboard: true };
// link personale: solo nome, indirizzo pubblico e rete dopo il "#" (non arriva a GitHub), mai la chiave
function viewKey(a) { if (!a.viewKey) { a.viewKey = crypto.randomBytes(16).toString("hex"); saveAcc(a); } return a.viewKey; }
function appLink(a) { return CFG.appUrl.replace(/#.*$/, "") + "#nome=" + encodeURIComponent(a.name) + "&addr=" + a.address + "&net=" + a.net + (CFG.apiOn && CFG.apiHost ? "&srv=" + CFG.apiHost + "&k=" + viewKey(a) : ""); }
function appMsg(a) {
  const code = CFG.apiOn && CFG.apiHost ? `\n\nSe hai già il tuo profilo in CashMkr, incolla questo codice nell'astronave (portale "Verifica") o nella cassaforte:\n${CFG.apiHost}/${viewKey(a)}\nServe solo per GUARDARE il tuo bot: non permette di modificare niente. Se finisce in mani sbagliate scrivi /app nuovo.` : "";
  return `📱 Il tuo link personale per CashMkr:\n\n${appLink(a)}\n\nAprilo sul telefono: crea il profilo "${a.name}" già collegato al tuo wallet${code ? " e associato al tuo bot (lo vedi con il portale \"Verifica\")" : ""}, devi solo scegliere la tua password.\nSu iPhone: aprilo in Safari e, PRIMA di scegliere la password, premi Condividi → "Aggiungi alla schermata Home". Poi apri CashMkr dall'icona e scegli lì la password (l'icona della Home ha una memoria sua, separata da Safari).\nNel link c'è l'indirizzo pubblico del wallet${code ? " e il codice per guardare il bot" : ""}, nessuna chiave: gli ordini li manda questo server.${code}`;
}
function tgSend(chatId, text) { if (chatId) tg("sendMessage", { chat_id: chatId, text, reply_markup: KB, disable_web_page_preview: true }); }
const accOf = chatId => [...ACC.values()].find(a => a.chatId === chatId);
const HELP = `Comandi CashMkr:
/stato — conto, bot acceso o fermo, impostazioni
/posizioni — posizioni aperte e protezioni
/storico — ultime operazioni chiuse
/avvia — accende il tuo bot · /ferma — lo spegne
/rischio 0.75 — rischio per operazione in % (da 0,1 a 3)
/maxpos 2 — posizioni insieme al massimo (1-4)
/controllo — confronto con Hyperliquid (posizioni, stop, ordini) · /sblocca — accetta le differenze trovate · /adotta BTC — fa gestire al bot una posizione aperta a mano
/esporta — file CSV con tutte le operazioni dell'anno per le tasse (anche in euro, cambio BCE) · /esporta 2025 — un anno a scelta
/allerte — allerte gravi (USDC sotto la parità, Hyperliquid in pericolo): stato dei controlli · /allerte prova — esempio · /opzione allerte off — le spegne
/opzione allarme off — niente avvisi se bot, conto o dati si fermano · /opzione buongiorno off — niente messaggio delle 9
/pastabank — riporta tutte le impostazioni di strategia alla strategia congelata PastaBank v1
/adattivo — rischio adattivo (piano B): 1,5% quando il saldo è al massimo, 0,75% sotto, tetto 2× (max 3%) · /adattivo 1.5 0.75 — cambia le due percentuali · /adattivo reset — dopo un deposito o un prelievo · /opzione adattivo off — lo spegne
/tetto 1.5 — rischio totale massimo di tutte le posizioni aperte in % (da 0,5 a 6) · /opzione tetto off — lo spegne
/moneta SOL off — accende o spegne una moneta
/strategia kelS off — accende o spegne una strategia (kel1h, mom1h, sq4h, kelS)
/classifica — moneta più forte e mercato in discesa
/settimana — resoconto della settimana (operazioni aperte, chiuse, totale)
/app — il tuo link personale per CashMkr (e il codice per guardare il bot con il teletrasporto) · /app nuovo — cambia il codice
/opzione limite on — entrata con ordine limite (maker, piano B a mercato dopo l'attesa) · /attesa 30 — minuti di attesa (1-120)
/opzione costanza on — modalità costanza · /opzione classifica off — solo le 2 più forti
/opzione blocco on — blocco perdita giornaliera · /opzione avvisi off — niente messaggi a ogni operazione
/opzione settimanale off — niente riepilogo automatico della domenica sera
/chiudi — chiude subito tutte le tue posizioni (chiede conferma)
/scollega — toglie il tuo wallet dal server`;
async function onMessage(msg) {
  const chatId = msg.chat && msg.chat.id, text = (msg.text || "").trim(); if (!chatId || !text) return;
  const [cmd0, ...args] = text.split(/\s+/), cmd = cmd0.toLowerCase().replace(/@.*/, "");
  const a = accOf(chatId), admin = CFG.adminChatId && chatId === CFG.adminChatId;
  if (cmd === "/start") return tgSend(chatId, `Ciao! Questo è il bot CashMkr.\n${a ? "Il tuo wallet è collegato: scrivi /stato." : "Per collegare il tuo wallet ti serve un codice di invito: chiedilo a chi gestisce il server, poi scrivi\n/collega CODICE INDIRIZZO CHIAVE"}\n\nIl tuo numero Telegram: ${chatId}`);
  if (cmd === "/admin") { if (args[0] && args[0].toUpperCase() === CFG.setupCode) { CFG.adminChatId = chatId; saveCfg(); return tgSend(chatId, "Sei l'amministratore del server.\n/invita Nome mainnet (o testnet) — crea un codice per collegare un wallet\n/utenti — elenco dei conti\n/fermatutti — ferma tutti i bot"); } return tgSend(chatId, "Codice non valido."); }
  if (cmd === "/invita") {
    if (!admin) return tgSend(chatId, "Solo l'amministratore può creare inviti.");
    const name = (args[0] || "").replace(/[^\p{L}\p{N}_-]/gu, "").slice(0, 20), net = (args[1] || "mainnet").toLowerCase() === "testnet" ? "testnet" : "mainnet";
    if (!name) return tgSend(chatId, "Scrivi /invita Nome mainnet (oppure testnet).");
    const code = crypto.randomBytes(3).toString("hex").toUpperCase(); CFG.invites[code] = { name, net, exp: now() + 2 * DAY }; saveCfg();
    return tgSend(chatId, `Invito per ${name} (${net}), valido 48 ore.\nCodice: ${code}\n\n${name} deve aprire questo bot su Telegram e scrivere:\n/collega ${code} INDIRIZZO_WALLET CHIAVE_API_WALLET\n(il messaggio viene cancellato subito dopo la lettura)`);
  }
  if (cmd === "/utenti") { if (!admin) return; return tgSend(chatId, [...ACC.values()].map(x => `${x.name} · ${x.net} · ${x.set.bot ? "acceso" : "fermo"} · rischio ${x.set.risk}% · posizioni ${Object.keys(x.real.pos).join(", ") || "nessuna"}${x._w ? " · conto " + usd2(x._w.acc.equity) : ""}`).join("\n") || "Nessun conto collegato."); }
  if (cmd === "/fermatutti") { if (!admin) return; for (const x of ACC.values()) { if (x.set.bot) { x.botStopped = now(); x.botSince = 0; } x.set.bot = false; saveAcc(x); alog(x, "Bot fermato dall'amministratore."); } return tgSend(chatId, "Tutti i bot fermati (le posizioni aperte restano protette dai loro stop)."); }
  if (cmd === "/collega") {
    tg("deleteMessage", { chat_id: chatId, message_id: msg.message_id });   // la chiave non resta nella chat
    const inv = CFG.invites[(args[0] || "").toUpperCase()];
    if (!inv || inv.exp < now()) return tgSend(chatId, "Codice di invito non valido o scaduto. Il tuo messaggio è stato cancellato.");
    const addr = (args[1] || "").replace(/\s/g, ""), key0 = (args[2] || "").replace(/\s/g, ""), key = key0.startsWith("0x") ? key0 : "0x" + key0;
    if (!/^0x[0-9a-fA-F]{40}$/.test(addr)) return tgSend(chatId, "Indirizzo del wallet non valido: deve essere 0x seguito da 40 caratteri (42 in tutto). Il messaggio è stato cancellato.");
    if (!/^0x[0-9a-fA-F]{64}$/.test(key)) return tgSend(chatId, `Chiave non valida: deve essere 0x seguito da 64 caratteri (66 in tutto), ne hai mandati ${key0.length}.${key0.length === 42 ? " Sembra un indirizzo: serve la CHIAVE PRIVATA dell'API wallet." : ""} Il messaggio è stato cancellato.`);
    if (a) return tgSend(chatId, "Hai già un wallet collegato. Scrivi prima /scollega.");
    const id = inv.name.toLowerCase() + "-" + crypto.randomBytes(2).toString("hex");
    const acc = { id, name: inv.name, net: inv.net, address: addr, key, chatId, set: newSettings(), real: { pos: {}, history: [], day: {} }, lastBar: {}, log: [], created: now() };
    const c = new HLM.Client(acc.net, addr, key);
    if (c.agentAddress().toLowerCase() === addr.toLowerCase()) return tgSend(chatId, "Questa sembra la chiave del wallet PRINCIPALE: non usarla. Crea un API wallet su Hyperliquid e manda la sua chiave. Il messaggio è stato cancellato.");
    try {
      const v = await c.verify(); if (!v.ok) return tgSend(chatId, "Verifica non riuscita: " + v.msg + "\nControlla di aver autorizzato l'API wallet sul conto giusto e sulla rete giusta (" + acc.net + ").");
      delete CFG.invites[(args[0] || "").toUpperCase()]; saveCfg();
      ACC.set(id, acc); saveAcc(acc); await refreshAcc(acc).catch(() => {});
      slog(`Nuovo conto collegato: ${acc.name} (${acc.net})`);
      return tgSend(chatId, `Wallet collegato e verificato (${acc.net}). ${acc._w ? "Valore del conto: " + usd2(acc._w.acc.equity) + "." : ""}\nIl tuo messaggio con la chiave è stato cancellato.\nIl bot è FERMO: controlla le impostazioni con /stato e scrivi /avvia quando vuoi partire.\nPer vedere il conto sul telefono scrivi /app.\n\n` + HELP);
    } catch (e) { return tgSend(chatId, "Verifica non riuscita: " + e.message); }
  }
  if (!a) return tgSend(chatId, "Non hai un wallet collegato. Ti serve un codice di invito, poi /collega CODICE INDIRIZZO CHIAVE.");
  const s = a.set;
  const on = v => /^(on|si|sì|1|acceso|accendi)$/i.test(v || ""), off = v => /^(off|no|0|spento|spegni)$/i.test(v || "");
  if (cmd === "/opzione" && /^https$/i.test(args[0] || "")) {
    if (!admin) return;
    if (!(on(args[1]) || off(args[1]))) return tgSend(chatId, `https: ${CFG.apiOn ? "acceso" : "spento"}${CFG.apiHost ? " · " + CFG.apiHost : " · nessun indirizzo (lancia attiva-https.sh sul server)"}. Scrivi /opzione https on oppure off.`);
    if (on(args[1]) && !CFG.apiHost) return tgSend(chatId, "Prima lancia sul server: bash ~/cashmkr-server/attiva-https.sh");
    CFG.apiOn = on(args[1]); saveCfg(); apiStart(); return tgSend(chatId, `https ${CFG.apiOn ? "acceso: le app vedono i bot con il teletrasporto" : "spento: il teletrasporto non riceve più dati"}.`);
  }
  switch (cmd) {
    case "/aiuto": case "/help": return tgSend(chatId, HELP);
    case "/esporta": {
      if (!s.exportOn) return tgSend(chatId, "Esportazione spenta: /opzione esporta on per accenderla.");
      const cy = new Date(now() + romeOffset(now())).getUTCFullYear(), year = args[0] ? parseInt(args[0]) : cy;
      if (!(year >= 2023 && year <= cy)) return tgSend(chatId, `Scrivi /esporta per il ${cy} oppure /esporta ANNO (dal 2023 al ${cy}).`);
      if (a._exporting) return tgSend(chatId, "Sto già preparando il file, un attimo.");
      a._exporting = true; tgSend(chatId, `Preparo il file delle operazioni ${year}…`);
      (async () => {
        try {
          const { fills, funding } = await Esporta.fetchYear(body => client(a).info(body), a.address, year);
          const fx = await Esporta.fxYear(async u => { const r = await fetch(u); if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); }, year);
          const out = Esporta.buildCsv({ fills, funding, hist: a.real.history, year, fx, name: a.name, net: a.net, stratName });
          const S = out.sum, fn = `cashmkr_${a.name.replace(/[^\w-]+/g, "_")}_${year}.csv`;
          await tgDoc(chatId, fn, out.csv, `📄 Operazioni ${year} · ${S.n} chiuse (${S.won} vinte) · netto con funding ${sgn(S.net)}${fx ? " · " + (S.eur >= 0 ? "+" : "−") + Math.abs(S.eur).toLocaleString("it-IT", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " €" : " · cambio BCE non disponibile"}\nSi apre con Excel o Numbers. È un aiuto per la dichiarazione, non un calcolo fiscale.`);
        } catch (e) { tgSend(chatId, "Non sono riuscito a preparare il file: " + e.message + ". Riprova tra qualche minuto."); }
        a._exporting = false;
      })();
      return;
    }
    case "/allerte": {
      if (/^prova$/i.test(args[0] || "")) return tgSend(chatId, alertMsg({ kind: "hl", test: true, items: [{ src: "CoinDesk", title: "Esempio: Hyperliquid bridge exploited, withdrawals paused", link: "https://www.coindesk.com/", t: now() }, { src: "The Block", title: "Esempio: Hyperliquid halts withdrawals after exploit", link: "https://www.theblock.co/", t: now() }] }));
      return tgSend(chatId, alertStatus(a));
    }
    case "/jeriko": {
      if (!admin) return;
      const acceso = /^(on|si|sì|1|acceso|accendi)$/i.test(args[0] || ""), spento = /^(off|no|0|spento|spegni)$/i.test(args[0] || "");
      if (!(acceso || spento)) return tgSend(chatId, `Resoconto a Jeriko OS: ${CFG.resocontoJeriko ? "acceso" : "spento"} (/jeriko on oppure /jeriko off)`);
      CFG.resocontoJeriko = acceso; saveCfg(); return tgSend(chatId, `Resoconto a Jeriko OS ${CFG.resocontoJeriko ? "acceso" : "spento"}.`);
    }
    case "/app": {
      if (args[0] && /^sito$/i.test(args[0])) { if (!admin) return; const u = (args[1] || "").trim(); if (!/^https:\/\/\S+$/.test(u)) return tgSend(chatId, "Scrivi per esempio /app sito https://tuonome.github.io/tuorepo/"); CFG.appUrl = u.replace(/#.*$/, ""); saveCfg(); return tgSend(chatId, "Indirizzo dell'app salvato: " + CFG.appUrl); }
      if (args[0] && /^nuovo$/i.test(args[0])) { a.viewKey = crypto.randomBytes(16).toString("hex"); saveAcc(a); return tgSend(chatId, "🔑 Codice nuovo creato: quello vecchio non funziona più.\n\n" + appMsg(a)); }
      return tgSend(chatId, appMsg(a));
    }
    case "/avvia": if (!s.bot) { a.botSince = now(); a.botSinceApprox = false; } s.bot = true; a.userStopped = false; saveAcc(a); return tgSend(chatId, `▶ Bot avviato (${a.net}) · ${presetTxt(s)}. ${s.adaptOn ? `Rischio adattivo ${s.riskHi}% / ${s.riskLo}%` : `Rischio ${s.risk}%`} · max ${s.maxPos} posizioni · monete ${coinsOn(a).join(", ")}.`);
    case "/ferma": if (s.bot) { a.botStopped = now(); a.botSince = 0; } s.bot = false; a.userStopped = true; stopPend(a); saveAcc(a); return tgSend(chatId, "■ Bot fermato: niente nuove entrate (gli ordini limite in attesa vengono annullati). Le posizioni aperte restano protette dai loro stop sull'exchange (/chiudi per chiuderle).");
    case "/rischio": { const v = parseFloat((args[0] || "").replace(",", ".")); if (!(v >= 0.1 && v <= 3)) return tgSend(chatId, "Scrivi un valore tra 0,1 e 3, per esempio /rischio 0.75"); s.risk = Math.round(v * 100) / 100; saveAcc(a); return tgSend(chatId, `Rischio per operazione: ${s.risk}%.`); }
    case "/controllo": { if (a._w) await reconcile(a).catch(() => {}); return tgSend(chatId, `Controllo con Hyperliquid: ${ctlTxt(a)}${a._ctl && a._ctl.issues.length ? "\n\n" + a._ctl.issues.map(x => (x.ignored ? "(accettata) " : "• ") + x.t).join("\n") : ""}\n\nOgni 15 secondi confronto posizioni, stop e ordini con il conto vero. Correggo da solo stop doppi o con la quantità sbagliata; per tutto il resto blocco le entrate e ti avviso. /opzione controllo off per spegnerlo.`); }
    case "/sblocca": { if (!a._ctl || !a._ctl.lock) return tgSend(chatId, "Nessun blocco attivo."); a._ctlIgnore = new Set([...(a._ctlIgnore || []), ...(a._ctl.keys || [])]); a._ctl.lock = false; a._ctl.issues.forEach(x => x.ignored = true); a._ctl.keys = []; return tgSend(chatId, "Ok, accetto queste differenze e il bot riprende le entrate. Se cambia qualcos'altro ti riavviso."); }
    case "/adotta": {
      const c = (args[0] || "").toUpperCase(), w = a._w || await refreshAcc(a).catch(() => null), p = w && w.acc.positions[c];
      if (!COINS.includes(c) || !p) return tgSend(chatId, `Scrivi /adotta seguito da una moneta con una posizione aperta sul conto (${w ? Object.keys(w.acc.positions).join(", ") || "nessuna aperta" : "conto non leggibile"}).`);
      if (a.real.pos[c]) return tgSend(chatId, `${c} è già gestita dal bot.`);
      const side = +p.szi > 0 ? 1 : -1, size = Math.abs(+p.szi), entry = +p.entryPx, st = stopOrders(a, c), m = signalsFor(c);
      const atr = m && m.SIG.kel1h ? m.SIG.kel1h.A[m.sigN - 1] : NaN, mid = midOf(a, c);
      let sl = st.length ? +st[0].triggerPx : (atr > 0 ? (side > 0 ? Math.min(entry, mid) - 2 * atr : Math.max(entry, mid) + 2 * atr) : NaN);
      if (!(sl > 0)) return tgSend(chatId, "Non riesco a calcolare lo stop adesso (mancano le candele): riprova tra un minuto.");
      try { if (!st.length) await client(a).placeStop(c, side < 0, size, sl); } catch (e) { return tgSend(chatId, `Stop non impostabile (${e.message}): posizione non adottata.`); }
      a.real.pos[c] = { coin: c, strat: "manuale", side, size, entry, sl, slD: Math.abs(entry - sl), lev: p.leverage && p.leverage.value, beDone: false, ex: {}, opened: now() }; saveAcc(a);
      return tgSend(chatId, `✅ ${c} ${side$(side)} ${size} adottata: stop a ${usd(sl)}${st.length ? " (quello già presente)" : " (2× ATR a 1 ora)"}. Il bot la protegge, non la chiude al segnale opposto.`);
    }
    case "/pastabank": { applyPreset(s); saveAcc(a); return tgSend(chatId, `◆ Ripristinata ${Core.presetLabel()}: ${Core.PRESET.desc}.\nIl bot resta ${s.bot ? "acceso" : "fermo"}; avvisi, blocco giornaliero e wallet non cambiano.`); }
    case "/adattivo": {
      const w = a._w || (a.key ? await refreshAcc(a).catch(() => null) : null);
      if (/^reset$/i.test(args[0] || "")) { if (!w) return tgSend(chatId, "Conto non leggibile adesso, riprova tra poco."); a.real.hwm = realizedOf(w.acc); saveAcc(a); return tgSend(chatId, `Massimo azzerato al saldo attuale ${usd2(a.real.hwm)}: il bot riparte dal rischio alto.`); }
      if (args.length >= 2) { const hi = parseFloat(args[0].replace(",", ".")), lo = parseFloat(args[1].replace(",", ".")); if (!(hi >= 0.1 && hi <= 3 && lo >= 0.1 && lo <= hi)) return tgSend(chatId, "Scrivi due valori tra 0,1 e 3, il primo maggiore o uguale al secondo: /adattivo 1.5 0.75"); s.riskHi = Math.round(hi * 100) / 100; s.riskLo = Math.round(lo * 100) / 100; s.adaptOn = true; saveAcc(a); }
      const ad = w ? adaptNow(a, w.acc) : null;
      return tgSend(chatId, `Rischio adattivo: ${s.adaptOn ? "acceso" : "spento"} · ${s.riskHi}% ai massimi, ${s.riskLo}% sotto · tetto ${s.capK}× il rischio (max ${s.capMax}%)${ad ? "\nAdesso: " + adaptTxt(a, ad) : ""}\nCon il rischio adattivo acceso /rischio e /tetto non contano; spento (/opzione adattivo off) valgono di nuovo.`);
    }
    case "/tetto": { const v = parseFloat((args[0] || "").replace(",", ".")); if (!(v >= 0.5 && v <= 6)) return tgSend(chatId, `Tetto di rischio totale: ${s.capOn ? s.cap + "%" : "spento"}. Scrivi un valore tra 0,5 e 6, per esempio /tetto 1.5 (per spegnerlo: /opzione tetto off)`); s.cap = Math.round(v * 100) / 100; s.capOn = true; saveAcc(a); return tgSend(chatId, `Tetto di rischio totale: ${s.cap}% del conto. Con le posizioni aperte vicine al tetto, le nuove entrano più piccole.`); }
    case "/attesa": { const v = parseInt(args[0]); if (!(v >= 1 && v <= 120)) return tgSend(chatId, `Entrata con ordine limite: ${s.limitOn ? "accesa" : "spenta (/opzione limite on)"} · attesa ${s.limWait} minuti prima del piano B a mercato. Scrivi un numero da 1 a 120, per esempio /attesa 30`); s.limWait = v; saveAcc(a); return tgSend(chatId, `Attesa prima del piano B: ${v} minuti${s.limitOn ? "" : " (l'entrata con ordine limite è spenta: /opzione limite on)"}.`); }
    case "/maxpos": { const v = parseInt(args[0]); if (!(v >= 1 && v <= 4)) return tgSend(chatId, "Scrivi un numero da 1 a 4."); s.maxPos = v; saveAcc(a); return tgSend(chatId, `Posizioni insieme al massimo: ${v}.`); }
    case "/moneta": { const c = (args[0] || "").toUpperCase(); if (!COINS.includes(c) || !(on(args[1]) || off(args[1]))) return tgSend(chatId, "Scrivi per esempio /moneta SOL off"); s.coins[c] = on(args[1]); saveAcc(a); return tgSend(chatId, `${c}: ${s.coins[c] ? "accesa" : "spenta"}. Monete accese: ${coinsOn(a).join(", ") || "nessuna"}.`); }
    case "/strategia": { const id = Object.keys(s.strats).find(k => k.toLowerCase() === (args[0] || "").toLowerCase()); if (!id || !(on(args[1]) || off(args[1]))) return tgSend(chatId, "Scrivi per esempio /strategia kelS off (strategie: kel1h, mom1h, sq4h, kelS)"); s.strats[id] = on(args[1]); saveAcc(a); return tgSend(chatId, `${stratName(id)}: ${s.strats[id] ? "accesa" : "spenta"}.`); }
    case "/opzione": {
      const map = { limite: "limitOn", costanza: "steady", classifica: "rsTop", tetto: "capOn", adattivo: "adaptOn", controllo: "ctlOn", allarme: "alarmOn", buongiorno: "morningOn", allerte: "alertsOn", esporta: "exportOn", blocco: "dailyLimit", avvisi: "notify", settimanale: "weekly" }, k = map[(args[0] || "").toLowerCase()];
      if (!k || !(on(args[1]) || off(args[1]))) return tgSend(chatId, "Opzioni: limite, costanza, classifica, adattivo, tetto, controllo, allarme, buongiorno, allerte, esporta, blocco, avvisi, settimanale. Esempio: /opzione costanza on");
      s[k] = on(args[1]); saveAcc(a);
      if (k === "limitOn") return tgSend(chatId, s.limitOn ? `Entrata con ordine limite ACCESA: il bot entra con un ordine limite (maker 0,015%) al miglior prezzo, con lo stop già agganciato. Se dopo ${s.limWait} minuti non è eseguito entra a mercato come prima (piano B). Attesa: /attesa 30` : "Entrata con ordine limite SPENTA: il bot entra a mercato come prima.");
      return tgSend(chatId, `${args[0]}: ${s[k] ? "acceso" : "spento"}.`);
    }
    case "/stato": {
      const w = a._w, eq = w ? w.acc.equity : null, d0 = a.real.day.startEq;
      const fr = COINS.map(c => failReason(c)).filter(Boolean);
      return tgSend(chatId, `${a.name} · ${a.net === "mainnet" ? "MAINNET (soldi veri)" : "TESTNET (prova)"}\nStrategia: ${presetTxt(s)}\nControllo: ${ctlTxt(a)}\nBot: ${s.bot ? "▶ ACCESO" : "■ FERMO"}${fr.length ? " · ⚠ dati di mercato: " + fr[0] : ""}${s.dailyLimit && a.real.day.locked === todayKey() ? "\n⚠ Perdita giornaliera raggiunta: niente nuove entrate fino a domani" : ""}\nConto: ${eq != null ? usd2(eq) : "—"}${eq != null && d0 ? " · oggi " + sgn(eq - d0) : ""}\nPosizioni: ${Object.keys(a.real.pos).join(", ") || "nessuna"}\n\n${s.adaptOn ? "Rischio adattivo: " + (a._w ? adaptTxt(a, adaptNow(a, a._w.acc)) : s.riskHi + "% / " + s.riskLo + "%") : "Rischio " + s.risk + "% · tetto totale " + (s.capOn ? s.cap + "%" : "spento")} · max ${s.maxPos} posizioni · leva max ${s.maxLev}x\nMonete: ${coinsOn(a).join(", ")}\nStrategie: ${Object.entries(s.strats).filter(([, v]) => v).map(([k]) => stratName(k)).join(", ")}\nSolo le 2 più forti: ${s.rsTop ? "sì" : "no"} · costanza: ${s.steady ? "sì" : "no"} · entrata: ${s.limitOn ? `ordine limite, attesa ${s.limWait} min (${a.real.limStats.lim} con limite, ${a.real.limStats.fb} piano B${Object.keys(a.real.pend).length ? ", " + Object.keys(a.real.pend).length + " in attesa" : ""})` : "a mercato"} · blocco giornaliero ${s.dailyLimit ? s.daily + "%" : "spento"} · avvisi: ${s.notify ? "sì" : "no"}`);
    }
    case "/posizioni": {
      const w = a._w; if (!w) return tgSend(chatId, "Conto non ancora letto, riprova tra qualche secondo.");
      const ps = Object.entries(w.acc.positions);
      return tgSend(chatId, ps.length ? ps.map(([c, p]) => { const P = a.real.pos[c], so = stopOrders(a, c); return `${c}: ${+p.szi > 0 ? "LONG" : "SHORT"} ${Math.abs(+p.szi)} · entrata ${usd(+p.entryPx)} · G/P ${sgn(+p.unrealizedPnl)}\n   stop: ${so.length ? so.map(o => usd(+o.triggerPx)).join(", ") : "⚠ nessuno"}${P ? " · " + stratName(P.strat) : " · non aperta dal bot"}`; }).join("\n") : "Nessuna posizione aperta.");
    }
    case "/storico": { const H = a.real.history.slice(-10).reverse(); const tot = a.real.history.reduce((x, h) => x + (isNaN(h.pnl) ? 0 : h.pnl), 0); return tgSend(chatId, H.length ? H.map(h => `${stamp(h.closed).slice(5, 16)} ${h.coin} ${h.side > 0 ? "L" : "S"} ${stratName(h.strat)}: ${isNaN(h.pnl) ? "?" : sgn(h.pnl)} (${h.why})`).join("\n") + `\n\nTotale ${a.real.history.length} operazioni: ${sgn(tot)}` : "Ancora nessuna operazione chiusa."); }
    case "/classifica": {
      const t = now(), rk = ranks(a, t), ord = coinsOn(a).slice().sort((x, y) => (rk[x] ?? 9) - (rk[y] ?? 9)), down = Core.btcDown(M.BTC.daily, t, 100);
      return tgSend(chatId, `Classifica (3, 7, 14 giorni):\n${ord.map((c, i) => `${i + 1}. ${c}${i < Core.RS.top ? " · long possibili" : ""}`).join("\n")}\n\nBTC ${down ? "SOTTO la media di 100 giorni: short intelligenti possibili su " + ord[ord.length - 1] : "sopra la media di 100 giorni: niente short"}.`);
    }
    case "/settimana": { const prev = /^(scorsa|prec)/i.test(args[0] || ""); const w0 = weekStartRome(now()) - (prev ? 7 * DAY : 0); return tgSend(chatId, await weekReport(a, w0)); }
    case "/chiudi": {
      if ((args[0] || "").toUpperCase() !== "SI") return tgSend(chatId, "Chiudere ADESSO a mercato tutte le tue posizioni? Scrivi /chiudi SI per confermare.");
      const np = Object.keys(a.real.pend || {}).length; if (np) { stopPend(a); saveAcc(a); }
      const cs = a._w ? Object.keys(a._w.acc.positions) : []; if (!cs.length) return tgSend(chatId, np ? `Nessuna posizione da chiudere; ${np} ordini limite in attesa annullati.` : "Nessuna posizione da chiudere.");
      for (const c of cs) enqueue(() => a.real.pos[c] ? doClose(a, c, "chiusa a mano") : client(a).closeMarket(c, SLIP_REAL).then(() => alog(a, `${c}: chiusa a mano.`)));
      return tgSend(chatId, "Chiusura in corso…");
    }
    case "/scollega": {
      if (Object.keys(a.real.pos).length && (args[0] || "").toUpperCase() !== "SI") return tgSend(chatId, "Hai posizioni aperte gestite dal bot: restano aperte con il loro stop ma il bot smette di seguirle. Scrivi /scollega SI per confermare.");
      for (const Q of Object.values(a.real.pend || {})) { const cl = client(a); enqueue(() => cl.cancel(Q.coin, Q.oid).catch(() => {}).then(() => cl.cancelTriggers(Q.coin)).catch(() => {})); }
      ACC.delete(a.id); try { fs.unlinkSync(accFile(a.id)); } catch (e) {} slog(`Conto scollegato: ${a.name}`);
      return tgSend(chatId, "Wallet scollegato: la chiave è stata cancellata dal server. Per sicurezza puoi anche eliminare l'API wallet dal sito di Hyperliquid.");
    }
    default: return tgSend(chatId, "Comando non riconosciuto. " + HELP);
  }
}
async function tgLoop() {
  while (true) {
    if (!CFG.telegramToken) { await new Promise(r => setTimeout(r, 5000)); continue; }
    const r = await tg("getUpdates", { offset: CFG.tgOffset, timeout: 25, allowed_updates: ["message"] });
    if (!r || !r.ok) { await new Promise(r2 => setTimeout(r2, 5000)); continue; }
    for (const u of r.result) { CFG.tgOffset = u.update_id + 1; saveCfg(); if (u.message) await onMessage(u.message).catch(e => slog("errore comando: " + e.message)); }
  }
}

/* ================= anti-inattività di Oracle (interruttore in config.json) ================= */
// Oracle può recuperare i server "Always Free" che restano quasi fermi per 7 giorni (processore sotto il 20%).
// Con antiInattivita acceso un lavoro a bassissima priorità tiene il processore poco sopra la soglia; si ferma da solo se serve al bot.
function antiIdle() {
  if (!CFG.antiInattivita || process.env.CASHMKR_NO_ANTIIDLE) return;
  const { Worker } = require("worker_threads"), n = require("os").cpus().length, duty = Math.min(0.9, CFG.antiCpu);
  for (let i = 0; i < n; i++) new Worker(`const d=${duty};function loop(){const t=Date.now();while(Date.now()-t<100*d){Math.sqrt(Math.random())}setTimeout(loop,100*(1-d))}loop()`, { eval: true });
  try { require("os").setPriority(19); } catch (e) {}
  slog(`Anti-inattività attivo: circa ${Math.round(duty * 100)}% del processore a bassa priorità (spegnibile in config.json).`);
}

/* ================= avvio ================= */
async function marketLoop() {
  let lastDaily = 0;
  for (;;) {
    JER.errore = "";
    try {
      await pollMids();
      if (now() - lastDaily > 3600000) { for (const c of COINS) await loadDaily(c); lastDaily = now(); }
      // candele: subito dopo ogni chiusura da 15 minuti, e comunque ogni minuto
      for (const c of COINS) if (!M[c].candles.length || now() - M[c].fetchAt > 60000 || Math.floor(now() / BAR) !== Math.floor(M[c].fetchAt / BAR)) await loadCandles(c);
      for (const c of COINS) onBar(c);
    } catch (e) { slog("dati di mercato non disponibili: " + e.message); JER.errore = "dati di mercato non disponibili: " + e.message; }
    try { weeklyTick(); } catch (e) {}
    // conti: lettura e protezione ogni 15 secondi
    for (const a of ACC.values()) if (a.key) await enqueue(() => refreshAcc(a).then(() => manageAcc(a)).then(() => refreshAcc(a)).then(() => reconcile(a)).catch(e => slog(`[${a.name}] lettura del conto non riuscita: ${e.message}`)));
    try { alarmTick(); } catch (e) { slog("allarme: " + e.message); }
    alertTick().catch(e => slog("allerte: " + e.message));
    JER.ultimoGiro = now(); jerikoTick().catch(() => {});
    await new Promise(r => setTimeout(r, +process.env.CASHMKR_LOOP_MS || 15000));
  }
}
/* ---------------- resoconto a Jeriko OS: il semaforo di PastaCrypto (solo il tuo conto) ---------------- */
const JER = { ultimoGiro: 0, errore: "", ultimoInvio: 0, fallimenti: 0 };
function jerikoBody() {
  const conti = [...ACC.values()].filter(a => CFG.adminChatId && a.chatId === CFG.adminChatId).map(a => ({
    nome: a.name, rete: a.net, bot: !!a.set.bot, eq: a._w ? +a._w.acc.equity : null, letto: a._w ? a._w.at : 0,
    posizioni: Object.keys(a.real.pos || {}).length, bloccoGiorno: !!(a.set.dailyLimit && a.real.day && a.real.day.locked === todayKey()) }));
  return { v: 1, at: now(), giro: JER.ultimoGiro, mercato: mktOk, errore: JER.errore, conti };
}
async function jerikoTick() {
  if (!CFG.resocontoJeriko || !CFG.jerikoUrl || !CFG.jerikoSecret) return;
  if (now() - JER.ultimoInvio < 60000) return;
  JER.ultimoInvio = now();
  try {
    const r = await fetch(CFG.jerikoUrl + "/api/cashmkr", { method: "POST", headers: { "Content-Type": "application/json", "X-CM-Secret": CFG.jerikoSecret }, body: JSON.stringify(jerikoBody()) });
    if (!r.ok) throw new Error("HTTP " + r.status);
    if (JER.fallimenti >= 5) slog("Resoconto a Jeriko OS di nuovo funzionante.");
    JER.fallimenti = 0;
  } catch (e) {
    JER.fallimenti++;
    if (JER.fallimenti === 5) slog("Resoconto a Jeriko OS non riuscito (" + e.message + "): controlla CASHMKR_SECRET su Cloudflare (node server.js jeriko)");
  }
}
/* ---------------- API di sola lettura per l'astronave dell'app (dietro Caddy, https) ---------------- */
const http = require("http");
let apiSrv = null; const hits = new Map();
function apiState(a) {
  const w = a._w, t = now(), rk = ranks(a, t), ord = coinsOn(a).slice().sort((x, y) => (rk[x] ?? 9) - (rk[y] ?? 9));
  const positions = w ? Object.entries(w.acc.positions).map(([c, p]) => { const P = a.real.pos[c]; return { coin: c, side: +p.szi > 0 ? 1 : -1, size: Math.abs(+p.szi), entry: +p.entryPx, upnl: +p.unrealizedPnl || 0, lev: p.leverage && p.leverage.value, liq: +p.liquidationPx || 0, stops: stopOrders(a, c).map(o => +o.triggerPx), strat: P ? P.strat : "", opened: P ? P.opened : 0 }; }) : [];
  return { v: 1, now: t, name: a.name, net: a.net, address: a.address, bot: !!a.set.bot, botSince: a.botSince || 0, botSinceApprox: !!a.botSinceApprox, botStopped: a.botStopped || 0, linked: a.created || 0,
    mkt: mktOk, at: w ? w.at : 0, ctl: { on: !!a.set.ctlOn, lock: !!(a._ctl && a._ctl.lock), start: !!a._startOk, issues: a._ctl ? a._ctl.issues : [] }, alarm: { on: !!a.set.alarmOn, morning: !!a.set.morningOn }, preset: Core.presetLabel(), presetDiff: presetDiff(a.set), set: { risk: a.set.risk, capOn: a.set.capOn, cap: a.set.cap, adaptOn: a.set.adaptOn, riskHi: a.set.riskHi, riskLo: a.set.riskLo, hwm: a.real.hwm || 0, maxPos: a.set.maxPos, maxLev: a.set.maxLev, rsTop: a.set.rsTop, steady: a.set.steady, dailyLimit: a.set.dailyLimit, daily: a.set.daily, coins: a.set.coins, strats: a.set.strats },
    eq: w ? w.acc.equity : null, dayStart: a.real.day && a.real.day.startEq || 0, dayLocked: !!(a.set.dailyLimit && a.real.day && a.real.day.locked === todayKey()),
    positions, hist: a.real.history.slice(-300), order: ord, btcDown: !!Core.btcDown(M.BTC.daily, t, 100), log: (a.log || []).slice(0, 30) };
}
function apiAcc(k) {
  if (typeof k !== "string" || !/^[0-9a-f]{32}$/.test(k)) return null;
  const kb = Buffer.from(k);
  for (const a of ACC.values()) if (a.viewKey && a.viewKey.length === k.length && crypto.timingSafeEqual(Buffer.from(a.viewKey), kb)) return a;
  return null;
}
function apiHandle(req, res) {
  const H = { "access-control-allow-origin": "*", "access-control-allow-methods": "POST, OPTIONS", "access-control-allow-headers": "content-type", "cache-control": "no-store", "content-type": "application/json; charset=utf-8" };
  const send = (code, obj) => { res.writeHead(code, H); res.end(JSON.stringify(obj)); };
  if (req.method === "OPTIONS") { res.writeHead(204, H); return res.end(); }
  const ip = String(req.headers["x-forwarded-for"] || req.socket.remoteAddress || "").split(",")[0].trim(), mn = Math.floor(Date.now() / 60000), h = hits.get(ip);
  if (h && h.m === mn) { if (++h.n > 40) return send(429, { error: "troppe richieste" }); } else hits.set(ip, { m: mn, n: 1 });
  if (hits.size > 5000) hits.clear();
  if (req.url === "/api/ping") return send(200, { ok: true, app: "cashmkr" });
  if (req.url !== "/api/stato" || req.method !== "POST") return send(404, { error: "non trovato" });
  let body = "";
  req.on("data", d => { body += d; if (body.length > 2000) req.destroy(); });
  req.on("end", () => { let k = ""; try { k = JSON.parse(body).k; } catch (e) {} const a = apiAcc(k); if (!a) return setTimeout(() => send(403, { error: "codice non valido" }), 400); try { send(200, apiState(a)); } catch (e) { send(500, { error: "errore" }); } });
}
function apiStart() {
  if (CFG.apiOn && !apiSrv) { apiSrv = http.createServer(apiHandle); apiSrv.on("error", e => { slog("API: " + e.message); apiSrv = null; }); apiSrv.listen(+process.env.CASHMKR_API_PORT || CFG.apiPort, process.env.CASHMKR_API_HOST || "127.0.0.1", () => slog(`API per l'app attiva su ${CFG.apiHost || "localhost"} (porta locale ${CFG.apiPort})`)); }
  if (!CFG.apiOn && apiSrv) { apiSrv.close(); apiSrv = null; slog("API per l'app spenta."); }
}
async function main() {
  const arg = process.argv[2];
  if (arg === "token") { CFG.telegramToken = (process.argv[3] || "").trim(); saveCfg(); console.log("Token Telegram salvato."); return; }
  if (arg === "https") { const d = (process.argv[3] || "").trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, ""); if (d === "off") { CFG.apiOn = false; saveCfg(); console.log("https spento."); return; } if (!/^[a-z0-9.-]+\.[a-z]{2,}$/.test(d)) { console.log("Uso: node server.js https NOME.duckdns.org"); return; } CFG.apiHost = d; CFG.apiOn = true; saveCfg(); console.log("https acceso per " + d); return; }
  if (arg === "jeriko") { console.log("Segreto per Jeriko OS: " + CFG.jerikoSecret + "\nSu Cloudflare: nome CASHMKR_SECRET, tipo Secret, valore questo; poi Deployments → Retry."); return; }
  if (arg === "codice") { console.log("Codice amministratore: " + CFG.setupCode + "\nScrivi al bot su Telegram: /admin " + CFG.setupCode); return; }
  if (arg === "stato") { loadAccounts(); for (const a of ACC.values()) console.log(`${a.name} · ${a.net} · ${a.set.bot ? "acceso" : "fermo"} · rischio ${a.set.risk}% · posizioni ${Object.keys(a.real.pos).join(", ") || "nessuna"}`); if (!ACC.size) console.log("Nessun conto collegato."); return; }
  loadAccounts();
  slog(`CashMkr Server avviato · ${ACC.size} conti · Telegram ${CFG.telegramToken ? "configurato" : "NON configurato (node server.js token TOKEN)"}`);
  if (!CFG.adminChatId) slog(`Per diventare amministratore scrivi al bot su Telegram: /admin ${CFG.setupCode}`);
  antiIdle();
  apiStart();
  tgLoop();
  marketLoop();
}
process.on("unhandledRejection", e => slog("errore: " + (e && e.message)));
module.exports = { Esporta, onMessage, ACC, M, CFG, apiState, apiHandle, reconcile, alarmTick, blocked, alertTick, alertHit, parseRss, AL, newSettings, doOpen, managePend, manageAcc, refreshAcc, stopPend };
if (require.main === module) main();
