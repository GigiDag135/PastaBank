#!/bin/bash
# Aggiornamento: bash aggiorna.sh INDIRIZZO_DEL_FILE_ZIP   (i dati registrati in data/ restano)
set -e
cd "$(dirname "$0")"; DIR="$(pwd)"
[ -z "$1" ] && { echo "Uso: bash aggiorna.sh https://.../jeriko-pepper.zip"; exit 1; }
TMP=$(mktemp -d); curl -fsSL "$1" -o "$TMP/s.zip"; unzip -q "$TMP/s.zip" -d "$TMP"
rm -rf "$TMP/jeriko-pepper/data"; cp -r "$TMP"/jeriko-pepper/. "$DIR"/; chmod +x "$DIR"/*.sh
rm -rf "$TMP"; sudo systemctl restart jeriko-pepper; echo "Aggiornato e riavviato. I dati registrati sono rimasti."
