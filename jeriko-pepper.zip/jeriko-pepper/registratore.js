// Jeriko · Pepper in osservazione: registratore dei dati di HLP.
// Non manda messaggi, non ha chiavi, non tocca soldi né CashMkr. Solo letture pubbliche da Hyperliquid.
// Comandi: node registratore.js            (avvio, lo usa il servizio)
//          node registratore.js stato      (cosa ha registrato finora)
//          node registratore.js on | off   (interruttore)
"use strict";
const fs = require("fs"), path = require("path");
const DIR = path.join(__dirname, "data"), CFG = path.join(DIR, "config.json");
const HLP = "0xdfc24b077bc1425ad1dea75bcb6f8158e10df303", API = "https://api.hyperliquid.xyz/info";
const F_HLP = path.join(DIR, "hlp-ora.csv"), F_STATO = path.join(DIR, "stato-exchange.csv"), LOG = path.join(DIR, "registro.log");
fs.mkdirSync(DIR, { recursive: true });
const DEF = { registratore: true, ogniMinutiHlp: 60, ogniMinutiStato: 5 };
const cfg = () => { try { return Object.assign({}, DEF, JSON.parse(fs.readFileSync(CFG, "utf8"))); } catch (e) { return Object.assign({}, DEF); } };
const saveCfg = c => fs.writeFileSync(CFG, JSON.stringify(c, null, 2));
if (!fs.existsSync(CFG)) saveCfg(DEF);
const log = m => { const l = new Date().toISOString() + "  " + m + "\n"; fs.appendFileSync(LOG, l); process.stdout.write(l); };
const info = async body => { const r = await fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal: AbortSignal.timeout(20000) }); if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); };

// --- HLP: salva i punti nuovi della serie "day" (ultime 24 ore, circa 1 punto all'ora) ---
function lastTime(file) { try { const t = fs.readFileSync(file, "utf8").trim().split("\n"); const l = t[t.length - 1].split(","); return +l[0] || 0; } catch (e) { return 0; } }
async function hlp() {
  const v = await info({ type: "vaultDetails", vaultAddress: HLP });
  const day = Object.fromEntries(v.portfolio).day; if (!day) throw new Error("serie day assente");
  const pnl = new Map(day.pnlHistory.map(([t, x]) => [t, x])); const last = lastTime(F_HLP);
  if (!fs.existsSync(F_HLP)) fs.writeFileSync(F_HLP, "tempo_ms,ora_utc,valore_vault_usd,risultato_cumulato_usd\n");
  let n = 0; for (const [t, av] of day.accountValueHistory) { if (t <= last || !pnl.has(t)) continue; fs.appendFileSync(F_HLP, `${t},${new Date(t).toISOString()},${av},${pnl.get(t)}\n`); n++; }
  return n;
}
// --- stato dell'exchange: annota solo le cose fuori dal normale, più un battito ogni ora ---
let lastBeat = 0, lastSpecial = "";
async function stato() {
  const s = await info({ type: "exchangeStatus" }); const now = Date.now();
  const t = +s.time || 0, ritardo = t ? Math.round((now - t) / 1000) : -1, spec = s.specialStatuses == null ? "" : JSON.stringify(s.specialStatuses);
  if (!fs.existsSync(F_STATO)) fs.writeFileSync(F_STATO, "tempo_ms,ora_utc,ritardo_chain_s,stato_speciale\n");
  const fuori = ritardo > 120 || spec !== "";
  if (fuori || spec !== lastSpecial || now - lastBeat > 3600e3) { fs.appendFileSync(F_STATO, `${now},${new Date(now).toISOString()},${ritardo},"${spec.replace(/"/g, "'")}"\n`); lastBeat = now; }
  if (fuori) log(`ATTENZIONE stato exchange: ritardo chain ${ritardo}s ${spec}`);
  lastSpecial = spec;
}
async function giro(nome, fn) { if (!cfg().registratore) return; try { const r = await fn(); if (nome === "hlp") log(`HLP: ${r} punti nuovi`); } catch (e) { log(`${nome}: errore ${e.message}`); } }

const cmd = process.argv[2];
if (cmd === "on" || cmd === "off") { const c = cfg(); c.registratore = cmd === "on"; saveCfg(c); console.log("Registratore " + (c.registratore ? "ACCESO" : "SPENTO") + ". (vale subito, senza riavvio)"); process.exit(0); }
if (cmd === "stato") {
  const c = cfg(); const righe = f => { try { return fs.readFileSync(f, "utf8").trim().split("\n").length - 1; } catch (e) { return 0; } };
  let primo = "-", ultimo = "-"; try { const t = fs.readFileSync(F_HLP, "utf8").trim().split("\n"); if (t.length > 1) { primo = t[1].split(",")[1]; ultimo = t[t.length - 1].split(",")[1]; } } catch (e) {}
  console.log(`Registratore: ${c.registratore ? "ACCESO" : "SPENTO"}\nPunti orari di HLP: ${righe(F_HLP)} (dal ${primo} al ${ultimo})\nRighe stato exchange: ${righe(F_STATO)}\nFile: ${F_HLP}\n      ${F_STATO}`);
  process.exit(0);
}
log("Avvio registratore (interruttore: " + (cfg().registratore ? "acceso" : "spento") + ")");
giro("hlp", hlp); giro("stato", stato);
setInterval(() => giro("hlp", hlp), cfg().ogniMinutiHlp * 60e3);
setInterval(() => giro("stato", stato), cfg().ogniMinutiStato * 60e3);
