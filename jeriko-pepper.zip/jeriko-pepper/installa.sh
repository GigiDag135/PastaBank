#!/bin/bash
# Installazione del registratore di Pepper (Jeriko) sul server Oracle. Si lancia una volta: bash installa.sh
set -e
cd "$(dirname "$0")"; DIR="$(pwd)"
echo "== Jeriko · registratore di Pepper: installazione in $DIR =="
command -v node >/dev/null || { echo "Node.js non trovato: installa prima CashMkr Server oppure Node 22."; exit 1; }
NODEV=$(node -e 'console.log(process.versions.node.split(".")[0])'); [ "$NODEV" -ge 18 ] || { echo "Serve Node 18 o più recente (hai $(node -v))."; exit 1; }
mkdir -p data && chmod 700 data
sudo tee /etc/systemd/system/jeriko-pepper.service >/dev/null <<UNIT
[Unit]
Description=Jeriko - registratore di Pepper (sola lettura)
After=network-online.target
Wants=network-online.target

[Service]
User=$USER
WorkingDirectory=$DIR
ExecStart=$(command -v node) $DIR/registratore.js
Restart=always
RestartSec=30
MemoryMax=120M

[Install]
WantedBy=multi-user.target
UNIT
sudo systemctl daemon-reload
sudo systemctl enable --now jeriko-pepper
sleep 3
echo
echo "== Fatto: il registratore è acceso e ripartirà da solo a ogni riavvio. =="
node registratore.js stato
echo
echo "Comandi utili:"
echo "  node registratore.js stato        cosa ha registrato"
echo "  node registratore.js off | on     interruttore"
echo "  sudo systemctl status jeriko-pepper"
echo "  tail -f $DIR/data/registro.log    registro in diretta (Ctrl+C per uscire)"
