#!/bin/bash
# Aggiornamento: bash aggiorna.sh INDIRIZZO_DEL_FILE_ZIP   (wallet, chiave, stato e storico in data/ restano)
set -e
cd "$(dirname "$0")"; DIR="$(pwd)"
[ -z "$1" ] && { echo "Uso: bash aggiorna.sh https://.../goldsilver-server.zip"; exit 1; }
TMP=$(mktemp -d); curl -fsSL "$1" -o "$TMP/s.zip"; unzip -q "$TMP/s.zip" -d "$TMP"
rm -rf "$TMP/goldsilver-server/data"
cp -r "$TMP"/goldsilver-server/. "$DIR"/
chmod +x "$DIR"/*.sh 2>/dev/null || true
rm -rf "$TMP"; sudo systemctl restart goldsilver; echo "Aggiornato e riavviato. Wallet, impostazioni e storico sono rimasti."
