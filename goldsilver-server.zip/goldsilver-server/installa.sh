#!/bin/bash
# Installazione di GoldSilver Server su Ubuntu (lo stesso server Oracle di CashMkr va benissimo). Si lancia una volta: bash installa.sh
set -e
cd "$(dirname "$0")"; DIR="$(pwd)"
echo "== GoldSilver Server: installazione in $DIR =="
sudo apt-get update -y >/dev/null
sudo apt-get install -y curl unzip >/dev/null
NODEV=$(node -e 'console.log(process.versions.node.split(".")[0])' 2>/dev/null || echo 0)
if [ "$NODEV" -lt 18 ]; then
  echo "Installo Node.js..."
  curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - >/dev/null
  sudo apt-get install -y nodejs >/dev/null
fi
echo "Node.js $(node -v) pronto."
mkdir -p data && chmod 700 data
if ! grep -q '"telegramToken": "[0-9]' data/config.json 2>/dev/null; then
  read -r -p "Incolla il token del NUOVO bot Telegram di GoldSilver (da @BotFather) e premi Invio: " TOK
  node server.js token "$TOK"
fi
sudo tee /etc/systemd/system/goldsilver.service >/dev/null <<UNIT
[Unit]
Description=GoldSilver Server (Jeriko)
After=network-online.target
Wants=network-online.target

[Service]
User=$USER
WorkingDirectory=$DIR
ExecStart=$(command -v node) $DIR/server.js
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
UNIT
sudo systemctl daemon-reload
sudo systemctl enable --now goldsilver
sleep 2
echo
echo "== Fatto: GoldSilver Server è acceso e ripartirà da solo a ogni riavvio. =="
node server.js codice
echo
node server.js jeriko
echo
echo "Comandi utili:"
echo "  sudo systemctl status goldsilver     stato del servizio"
echo "  tail -f $DIR/data/registro.log       registro in diretta (Ctrl+C per uscire)"
echo "  sudo systemctl stop goldsilver       spegne il servizio (lo riaccendi con start)"
