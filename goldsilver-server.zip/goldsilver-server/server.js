#!/usr/bin/env node
// GoldSilver Server: il bot della scrivania GoldSilver di Jeriko (argento su xyz:SILVER, oro su PAXG).
// Segnali sulle candele Dukascopy (le stesse del banco prova), ordini su Hyperliquid con stop sempre sull'exchange.
// Si comanda da Telegram; da solo scrive solo per gli avvisi gravi. Separato da CashMkr Server: wallet, chiave e dati suoi.
"use strict";
const fs = require("fs"), path = require("path"), crypto = require("crypto");
const E = require("./lib/engine.js"), GS = require("./lib/strat.js"), HLM = require("./lib/hl.js"), DK = require("./lib/duka.js");

/* ---------------- impostazioni ---------------- */
const DIR = process.env.GS_DATA || path.join(__dirname, "data");
fs.mkdirSync(DIR, { recursive: true });
const CFG_FILE = path.join(DIR, "config.json"), ST_FILE = path.join(DIR, "stato.json"), KEY_FILE = path.join(DIR, "chiave.txt");
if (process.env.GS_HL_URL) HLM.URLS.mainnet = process.env.GS_HL_URL;
const TG = process.env.GS_TG_URL || "https://api.telegram.org";
const now = () => Date.now() + (+process.env.GS_NOW_OFFSET || 0);
const BAR = DK.BAR, DAY = 86400000, MKTS = Object.keys(GS.MARKETS);
const SLIP_REAL = 0.005, HISTORY_DAYS = 200, DD_LIMIT = 0.20;

const readJ = (f, d) => { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch (e) { return d; } };
const writeJ = (f, o) => { const tmp = f + ".tmp"; fs.writeFileSync(tmp, JSON.stringify(o, null, 1), { mode: 0o600 }); fs.renameSync(tmp, f); };
const FUNZ_DEF = { avvisoDiscesa: true, avvisoErrori: true, avvisoCommissioni: true, riservaHyperliquid: true, antiInattivita: false, resocontoJeriko: true };
const FUNZ_TXT = { avvisoDiscesa: "avviso e domanda se la discesa supera il 20%", avvisoErrori: "avviso se il bot è fermo o in errore", avvisoCommissioni: "avviso se l'argento esce dal growth mode", riservaHyperliquid: "candele di riserva da Hyperliquid se Dukascopy non risponde", antiInattivita: "anti-inattività di Oracle (lascialo spento se gira già CashMkr Server)", resocontoJeriko: "manda ogni minuto il resoconto al PC 1 di Jeriko OS" };
let CFG = Object.assign({ telegramToken: "", setupCode: crypto.randomBytes(4).toString("hex").toUpperCase(), adminChatId: 0, tgOffset: 0, net: "mainnet", address: "",
  jerikoUrl: "https://jeriko-os.pages.dev", jerikoSecret: crypto.randomBytes(24).toString("hex") }, readJ(CFG_FILE, {}));
CFG.funzioni = Object.assign({}, FUNZ_DEF, CFG.funzioni || {});
const saveCfg = () => writeJ(CFG_FILE, CFG);
saveCfg();
let ST = Object.assign({ on: false, cfg: GS.clean(GS.BEST), cfgPrev: null, pos: {}, hist: [], peak: 0, ddAsked: false, lastBar: {}, growthAlert: false, pending: null, since: 0 }, readJ(ST_FILE, {}));
const saveSt = () => writeJ(ST_FILE, ST);
const KEY = () => { try { return fs.readFileSync(KEY_FILE, "utf8").trim(); } catch (e) { return ""; } };

/* ---------------- registro ---------------- */
const LOGF = path.join(DIR, "registro.log");
const stamp = t => new Date(t || now()).toISOString().replace("T", " ").slice(0, 19);
function slog(msg) { const line = stamp() + "  " + msg; console.log(line); try { fs.appendFileSync(LOGF, line + "\n"); } catch (e) {} }

/* ---------------- formati ---------------- */
const usd2 = v => (v < 0 ? "−" : "") + "$" + Math.abs(v).toLocaleString("it-IT", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const px = v => (+v).toLocaleString("it-IT", { maximumFractionDigits: v < 100 ? 4 : 2 });
const pct = v => (v >= 0 ? "+" : "−") + Math.abs(v * 100).toLocaleString("it-IT", { maximumFractionDigits: 1 }) + "%";
const strat = id => ST.cfg.strats.find(s => s.id === id);
const exTxt = x => [`stop ${x.sl}× ATR`, x.rr ? `obiettivo ${x.rr}:1` : "", x.tr ? `trailing ${x.tr}× ATR` : "", x.opp ? "chiude al segnale opposto" : "", x.bars ? `massimo ${x.bars / 4} ore di mercato` : "", x.be ? `pareggio dopo +${x.be}R` : ""].filter(Boolean).join(" · ");
const sTxt = s => `${s.on ? "🟢" : "⚪️"} ${s.name} [${s.id}]\n   ${E.STRATS[s.key].name} · ${GS.TF_NAMES[s.f] || s.f * 15 + " min"} · ${s.dir === "L" ? "solo long" : s.dir === "S" ? "solo short" : "long e short"} · ${Object.entries(s.p).map(([k, v]) => k + " " + v).join(", ")}\n   ${exTxt(s.ex)}`;

/* ================= mercato: candele e segnali ================= */
const MK = Object.fromEntries(MKTS.map(m => [m, { rows: readJ(path.join(DIR, `candele-${m}.json`), []), src: "", at: 0, fail: 0, lastOk: 0 }]));
async function hlInfo(body) { const r = await fetch(HLM.URLS.mainnet + "/info", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }); if (!r.ok) throw new Error("Hyperliquid HTTP " + r.status); return r.json(); }
async function updateCandles(m) {
  const k = MK[m], mk = GS.MARKETS[m];
  try {
    k.rows = await DK.dukaUpdate(mk.duka, k.src === "duka" ? k.rows : [], HISTORY_DAYS, now());
    k.src = "duka"; k.fail = 0; k.lastOk = now(); writeJ(path.join(DIR, `candele-${m}.json`), k.rows);
  } catch (e) {
    k.fail++; slog(`${mk.name}: Dukascopy non risponde (${e.message})`);
    if (CFG.funzioni.riservaHyperliquid && k.fail >= 3) {
      try { k.rows = await DK.hlUpdate(hlInfo, mk.coin, now()); k.src = "hl"; k.lastOk = now(); slog(`${mk.name}: uso le candele di riserva di Hyperliquid`); } catch (e2) { slog(`${mk.name}: anche Hyperliquid non risponde (${e2.message})`); }
    }
  }
  k.at = now();
}
// il mercato dei metalli è chiuso da venerdì 21:00 a domenica 22:00 UTC (più alcune festività)
const marketClosed = t => DK.closedHours(t);

/* ================= conto ================= */
let client = null, W = null;   // W = ultima lettura del conto
function makeClient() { const k = KEY(); client = CFG.address && k ? new HLM.Client(CFG.net, CFG.address, k, ["xyz"]) : null; }
async function readAccount() {
  if (!client) return null;
  const [acc, orders, mids] = await Promise.all([client.account(), client.openOrders(), client.mids()]);
  W = { acc, orders, mids, at: now() }; return W;
}
const fee = m => GS.MARKETS[m].feeDefault;
const subsOn = coin => Object.values(ST.pos).filter(P => P.coin === coin);

/* ================= Telegram ================= */
async function tg(method, body) {
  if (!CFG.telegramToken) return null;
  try { const r = await fetch(`${TG}/bot${CFG.telegramToken}/${method}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) }); return await r.json(); }
  catch (e) { slog("Telegram non raggiungibile: " + e.message); return null; }
}
const KB = { keyboard: [[{ text: "/stato" }, { text: "/posizioni" }, { text: "/storico" }], [{ text: "/strategie" }, { text: "/avvia" }, { text: "/ferma" }], [{ text: "/aiuto" }]], resize_keyboard: true };
function send(text, buttons) { if (!CFG.adminChatId) return; return tg("sendMessage", { chat_id: CFG.adminChatId, text, disable_web_page_preview: true, reply_markup: buttons ? { inline_keyboard: buttons } : KB }); }
const grave = (text, buttons) => { slog("AVVISO: " + text.replace(/\n/g, " ")); return send("🚨 GoldSilver\n" + text, buttons); };

/* ================= ordini ================= */
let queue = Promise.resolve();
const enqueue = fn => (queue = queue.then(fn).catch(e => { slog("errore: " + e.message); ERR.note(e); }));
function ownedOids() { const s = new Set(); for (const P of Object.values(ST.pos)) { if (P.slOid) s.add(P.slOid); if (P.tpOid) s.add(P.tpOid); } return s; }
function findTrigger(orders, coin, sz, trig, kind) {
  const own = ownedOids();
  return orders.filter(o => o.coin === coin && o.isTrigger && o.reduceOnly && !own.has(o.oid) && Math.abs(+o.sz - sz) < 1e-9 + sz * 1e-6 && (!kind || (kind === "sl" ? /stop/i.test(o.orderType || "") : /take/i.test(o.orderType || ""))))
    .sort((a, b) => Math.abs(+a.triggerPx - trig) - Math.abs(+b.triggerPx - trig))[0];
}
async function doOpen(s, side, slPct, trPct) {
  const mk = GS.MARKETS[s.mkt], coin = mk.coin;
  try {
    await readAccount();
    const mid = parseFloat(W.mids[coin]), meta = await client.coinMeta(coin);
    if (!(mid > 0)) return slog(`${s.name}: prezzo di ${coin} non disponibile, segnale saltato`);
    const others = subsOn(coin);
    if (others.some(P => P.side !== side)) return slog(`${s.name}: segnale ${side > 0 ? "long" : "short"} saltato, su ${coin} c'è una posizione nel verso opposto`);
    const z = GS.sizing(W.acc.equity, ST.cfg.risk, slPct, fee(s.mkt), Math.min(meta.maxLeverage, mk.maxLev));
    let lev = z.lev, notional = z.notional;
    if (others.length) { lev = others[0].lev; if (notional / lev > W.acc.available * 0.95) notional = W.acc.available * 0.95 * lev; }
    const sz = HLM.roundSz(notional / mid, meta.szDecimals);
    if (sz * mid < 10.5) return slog(`${s.name}: ordine non inviato, valore ${usd2(sz * mid)} sotto il minimo di 10 $ (conto ${usd2(W.acc.equity)})`);
    const sl = mid * (1 - side * slPct), tp = s.ex.rr ? mid * (1 + side * slPct * s.ex.rr) : 0;
    if (!others.length) await client.setLeverage(coin, lev);
    const st = await client.openProtected(coin, side > 0, sz, mid, sl, tp, SLIP_REAL), f = st[0] && st[0].filled;
    if (!f) { ERR.note(new Error("ordine rifiutato")); return slog(`${s.name}: ordine rifiutato: ` + ((st[0] && st[0].error) || JSON.stringify(st[0]))); }
    const size = +f.totalSz, entry = +f.avgPx;
    await new Promise(r => setTimeout(r, 1500));
    const orders = await client.openOrders();
    const slO = findTrigger(orders, coin, size, sl, "sl"), tpO = tp ? findTrigger(orders, coin, size, tp, "tp") : null;
    const P = { id: s.id, name: s.name, mkt: s.mkt, coin, side, size, entry, lev, sl: +HLM.roundPx(sl, meta.szDecimals), slOid: slO ? slO.oid : 0, tp, tpOid: tpO ? tpO.oid : 0, slPct0: slPct, trPct, ex: s.ex, bars: 0, best: entry, beDone: false, opened: now(), riskAmt: z.riskAmt, stratDef: s };
    ST.pos[s.id] = P; saveSt();
    slog(`${s.name}: aperto ${side > 0 ? "LONG" : "SHORT"} ${size} ${coin} a ${px(entry)}, stop ${px(P.sl)}${tp ? ", obiettivo " + px(tp) : ""}, leva ${lev}x, rischio ${usd2(z.riskAmt)}`);
    if (!P.slOid) { slog(`${s.name}: stop non trovato tra gli ordini, lo rimetto`); await ensureStop(P); }
  } catch (e) { ERR.note(e); slog(`${s.name}: errore nell'apertura: ${e.message}`); }
}
async function ensureStop(P) {
  try { P.slOid = await client.placeTrigger(P.coin, P.side < 0, P.size, P.sl, "sl"); saveSt(); slog(`${P.name}: stop rimesso sull'exchange a ${px(P.sl)}`); }
  catch (e) { slog(`${P.name}: stop non impostabile (${e.message}), chiudo per sicurezza`); ERR.note(e); await doClose(P, "Sicurezza: stop non attivo"); }
}
async function recordClose(P, exitPx, why) {
  const gross = (exitPx - P.entry) * P.side * P.size, fees = (P.entry + exitPx) * P.size * fee(P.mkt), pnl = gross - fees;
  ST.hist.push({ id: P.id, name: P.name, coin: P.coin, side: P.side, size: P.size, entry: P.entry, exit: exitPx, opened: P.opened, closed: now(), why, pnl, r: P.riskAmt ? pnl / P.riskAmt : 0 });
  ST.hist = ST.hist.slice(-500); delete ST.pos[P.id]; saveSt();
  slog(`${P.name}: chiuso ${P.side > 0 ? "LONG" : "SHORT"} a ${px(exitPx)} · ${why} · ${usd2(pnl)}`);
}
async function doClose(P, why) {
  try {
    const f = await client.reduceMarket(P.coin, P.side < 0, P.size, SLIP_REAL);
    for (const oid of [P.slOid, P.tpOid]) if (oid) { try { await client.cancel(P.coin, oid); } catch (e) {} }
    await recordClose(P, f ? +f.avgPx : parseFloat((W && W.mids[P.coin]) || P.entry), why);
  } catch (e) { P.closing = false; ERR.note(e); slog(`${P.name}: chiusura non riuscita: ${e.message}`); }
}
async function moveStop(P, nsl) {
  const meta = await client.coinMeta(P.coin), r = HLM.roundPx(nsl, meta.szDecimals);
  if (Math.abs(r - P.sl) < P.entry * 0.0005) return;          // spostamenti minuscoli: non serve rifare l'ordine
  const old = P.slOid, oid = await client.placeTrigger(P.coin, P.side < 0, P.size, r, "sl");   // prima il nuovo, poi via il vecchio
  if (old) { try { await client.cancel(P.coin, old); } catch (e) {} }
  P.sl = r; P.slOid = oid; saveSt(); slog(`${P.name}: stop spostato a ${px(r)}`);
}
// a ogni giro: stop o obiettivo scattati sull'exchange, stop mancanti
async function protect() {
  if (!W) return;
  const open = new Set(W.orders.map(o => o.oid)); let fills = null;
  for (const P of Object.values(ST.pos)) {
    if (P.closing) continue;
    const slGone = P.slOid && !open.has(P.slOid), tpGone = P.tpOid && !open.has(P.tpOid);
    if (!P.slOid || slGone || tpGone) {
      if (!fills) fills = await client.fills(Math.min(...Object.values(ST.pos).map(x => x.opened)) - 60000);
      const fx = fills.filter(x => x.coin === P.coin && (x.oid === P.slOid || (P.tpOid && x.oid === P.tpOid)));
      if (fx.length) {
        const q = fx.reduce((a, x) => a + +x.sz, 0), avg = fx.reduce((a, x) => a + +x.px * +x.sz, 0) / q, byTp = fx.some(x => x.oid === P.tpOid);
        for (const oid of [P.slOid, P.tpOid]) if (oid && open.has(oid)) { try { await client.cancel(P.coin, oid); } catch (e) {} }
        await recordClose(P, avg, byTp ? "Obiettivo" : "Stop"); continue;
      }
      const pos = W.acc.positions[P.coin], have = pos ? Math.abs(+pos.szi) : 0;
      if (have < P.size * 0.5 && !subsOn(P.coin).some(x => x !== P)) { await recordClose(P, parseFloat(W.mids[P.coin]) || P.entry, "Chiusa fuori dal bot"); continue; }
      if (!P.slOid || slGone) { if (now() - P.opened > 5000) await ensureStop(P); }
      if (tpGone) { P.tpOid = 0; saveSt(); }
    }
  }
  // controllo: la somma delle posizioni del bot deve corrispondere all'exchange
  for (const coin of new Set(Object.values(ST.pos).map(P => P.coin))) {
    const want = subsOn(coin).reduce((a, P) => a + P.side * P.size, 0), pos = W.acc.positions[coin], have = pos ? +pos.szi : 0;
    if (Math.abs(want - have) > Math.abs(want) * 0.02 + 1e-9) ERR.mismatch(coin, want, have); else ERR.mismatchOk(coin);
  }
}

/* ================= candele chiuse: uscite e nuove entrate ================= */
function onBars(m) {
  const k = MK[m]; if (!k.rows.length) return;
  const C = DK.toC(k.rows), N = C.t.length, strs = ST.cfg.strats.filter(s => s.mkt === m);
  // segnali delle strategie attuali e, per le posizioni aperte, della versione con cui sono nate
  const SIG = GS.signals(C, strs);
  const posDefs = Object.values(ST.pos).filter(P => P.mkt === m && P.stratDef).map(P => Object.assign({}, P.stratDef, { id: "p_" + P.id }));
  const SIGP = GS.signals(C, posDefs);
  const last = ST.lastBar[m] || 0, fresh = []; for (let i = 0; i < N; i++) if (C.t[i] > last) fresh.push(i);
  if (!fresh.length) return;
  ST.lastBar[m] = C.t[N - 1]; saveSt();
  if (!last) { slog(`${GS.MARKETS[m].name}: storico pronto (${N} candele), parto dalla prossima chiusura`); return; }
  const coin = GS.MARKETS[m].coin, mid = W ? parseFloat(W.mids[coin]) : 0, ratio = mid > 0 ? mid / C.c[N - 1] : 1;
  for (const i of fresh) {
    for (const P of Object.values(ST.pos).filter(P => P.mkt === m && !P.closing)) {
      const x = SIGP["p_" + P.id]; const bar ={ h: C.h[i] * ratio, l: C.l[i] * ratio, c: C.c[i] * ratio };
      const a = GS.onBarClose(P, bar, x ? x.raw[i] : 0, fee(m)); saveSt();
      if (a.close) { P.closing = true; enqueue(() => doClose(P, a.close)); }
      else if (a.sl) enqueue(() => moveStop(P, a.sl));
    }
  }
  const i = N - 1, liveBar = now() - (C.t[i] + BAR) < 10 * 60000;
  if (!liveBar || !ST.on || !client) return;
  if (marketClosed(now())) return slog(`${GS.MARKETS[m].name}: mercato chiuso (weekend), nessuna nuova entrata`);
  for (const s of strs) {
    const x = SIG[s.id], d = x.sig[i];
    if (!d || isNaN(x.A[i]) || !s.on || ST.pos[s.id]) continue;
    const slPct = s.ex.sl * x.A[i] / C.c[i], trPct = (s.ex.tr || 0) * x.A[i] / C.c[i];
    slog(`${s.name}: segnale ${d > 0 ? "LONG" : "SHORT"} (dati ${MK[m].src === "duka" ? "Dukascopy" : "Hyperliquid di riserva"})`);
    const sd = JSON.parse(JSON.stringify(s)); enqueue(() => doOpen(sd, d, slPct, trPct));
  }
}

/* ================= avvisi gravi ================= */
const ERR = {
  streak: 0, last: 0, alerted: false, mm: {},
  note(e) { this.lastMsg = e && e.message; },
  cycle(ok) {
    if (ok) { if (this.alerted) { send("✅ GoldSilver funziona di nuovo."); this.alerted = false; } this.streak = 0; return; }
    this.streak++;
    if (this.streak >= 4 && CFG.funzioni.avvisoErrori && now() - this.last > 2 * 3600000) { this.last = now(); this.alerted = true; grave(`Il bot è in errore da qualche minuto: ${this.lastMsg || "motivo sconosciuto"}.\nLe posizioni aperte restano protette dagli stop sull'exchange.`); }
  },
  mismatch(coin, want, have) { const m = this.mm[coin] = this.mm[coin] || { n: 0, at: 0 }; m.n++; if (m.n >= 8 && CFG.funzioni.avvisoErrori && now() - m.at > 2 * 3600000) { m.at = now(); grave(`Su ${coin} il bot si aspetta ${want} ma sull'exchange c'è ${have}. Controlla su Hyperliquid (forse un ordine fatto a mano).`); } },
  mismatchOk(coin) { if (this.mm[coin]) this.mm[coin].n = 0; },
};
let dataAlertAt = 0;
function dataCheck() {
  if (marketClosed(now())) return;
  for (const m of MKTS) { const k = MK[m], lastT = k.rows.length ? k.rows[k.rows.length - 1][0] : 0;
    if (now() - lastT > 90 * 60000 && now() - dataAlertAt > 3 * 3600000 && CFG.funzioni.avvisoErrori && k.at) { dataAlertAt = now(); grave(`Niente candele nuove di ${GS.MARKETS[m].name.toLowerCase()} da più di 90 minuti (fonte: ${k.src || "nessuna"}). Se oggi è festivo il mercato è chiuso e va bene; altrimenti il bot non può aprire nuove posizioni.`); } }
}
function ddCheck() {
  if (!W || !(W.acc.equity > 0)) return;
  const eq = W.acc.equity;
  if (eq > ST.peak) { ST.peak = eq; if (ST.ddAsked) ST.ddAsked = false; saveSt(); return; }
  const dd = 1 - eq / ST.peak;
  if (dd > DD_LIMIT && !ST.ddAsked && CFG.funzioni.avvisoDiscesa) {
    ST.ddAsked = true; saveSt();
    grave(`La discesa ha superato il 20% dal massimo (conto ${usd2(eq)}, massimo ${usd2(ST.peak)}, ${pct(-dd)}). È peggio della discesa più grande vista nella prova sul passato.\nCosa vuoi fare? Intanto il bot continua a lavorare.`, [[{ text: "⏹ Ferma GoldSilver", callback_data: "dd_stop" }, { text: "▶️ Continua", callback_data: "dd_go" }]]);
  }
}
async function growthCheck() {
  try {
    const m = (await hlInfo({ type: "meta", dex: "xyz" })).universe.find(a => a.name === "xyz:SILVER"), on = m && m.growthMode === "enabled";
    if (!on && !ST.growthAlert) { ST.growthAlert = true; saveSt(); if (CFG.funzioni.avvisoCommissioni) grave("L'argento su Hyperliquid è uscito dal growth mode: le commissioni salgono da 0,009% a circa 0,09% a operazione. Con questi costi le strategie dell'argento rendono molto meno (prova sul passato: da 7,8% a circa 2% l'anno). Valuta se spegnerle con /strategie."); }
    if (on && ST.growthAlert) { ST.growthAlert = false; saveSt(); send("ℹ️ L'argento è tornato in growth mode (commissioni ridotte)."); }
  } catch (e) { slog("controllo growth mode non riuscito: " + e.message); }
}

/* ================= comandi ================= */
const HELP = `Comandi GoldSilver:
/stato — interruttore, conto, discesa, strategie, fonte dei dati
/posizioni — posizioni aperte con stop
/storico — ultime operazioni chiuse e totale
/avvia — accende GoldSilver · /ferma — la spegne (le posizioni aperte restano con lo stop)
/strategie — elenco con i pulsanti per accenderle e spegnerle
/strategia ag4h off — accende o spegne una strategia
/applica CODICE — usa la versione preparata nel banco prova (chiede conferma)
/ripristina — torna alla versione precedente · /migliore — torna alla configurazione migliore della ricerca
/azzera — riparte a misurare la discesa da oggi (dopo un versamento o un prelievo)
/opzione — elenco degli interruttori delle funzioni · /opzione avvisoErrori off
/chiudi — chiude subito tutte le posizioni (chiede conferma)
/scollega — toglie wallet e chiave dal server`;
function statoTxt() {
  const lines = [`GoldSilver ${ST.on ? "🟢 ACCESA" : "⚪️ SPENTA"}${CFG.address ? " · wallet " + CFG.address.slice(0, 6) + "…" + CFG.address.slice(-4) : " · wallet non collegato"}`];
  if (W) { const dd = ST.peak ? 1 - W.acc.equity / ST.peak : 0; lines.push(`Conto ${usd2(W.acc.equity)} · massimo ${usd2(ST.peak || W.acc.equity)} · discesa ${pct(-dd)}`); lines.push(`Margine libero ${usd2(W.acc.available)} (principale ${usd2((W.acc.byDex.main || {}).withdrawable || 0)}, xyz ${usd2((W.acc.byDex.xyz || {}).withdrawable || 0)})`); }
  lines.push(`Rischio ${(ST.cfg.risk * 100).toLocaleString("it-IT")}% per operazione · versione ${ST.cfg.v}`);
  for (const s of ST.cfg.strats) lines.push(sTxt(s));
  for (const m of MKTS) { const k = MK[m], lt = k.rows.length ? k.rows[k.rows.length - 1][0] : 0; lines.push(`${GS.MARKETS[m].name}: dati ${k.src === "duka" ? "Dukascopy" : k.src === "hl" ? "Hyperliquid (riserva)" : "non ancora caricati"}${lt ? ", ultima candela " + stamp(lt + BAR).slice(5, 16) + " UTC" : ""}`); }
  lines.push(`Argento ${ST.growthAlert ? "⚠️ fuori dal growth mode" : "in growth mode (commissioni ridotte)"}`);
  return lines.join("\n");
}
function posTxt() {
  const P = Object.values(ST.pos); if (!P.length) return "Nessuna posizione aperta.";
  return P.map(p => { const mid = W ? parseFloat(W.mids[p.coin]) : 0, up = mid ? (mid - p.entry) * p.side * p.size : 0;
    return `${p.name}\n   ${p.side > 0 ? "LONG" : "SHORT"} ${p.size} ${p.coin} a ${px(p.entry)} · ora ${mid ? px(mid) : "?"} (${usd2(up)})\n   stop ${px(p.sl)}${p.slOid ? "" : " ⚠️ non trovato"}${p.tp ? " · obiettivo " + px(p.tp) : ""} · aperta ${stamp(p.opened).slice(5, 16)} · ${p.bars} candele`; }).join("\n");
}
function histTxt() {
  const H = ST.hist.slice(-12); if (!H.length) return "Nessuna operazione chiusa.";
  const tot = ST.hist.reduce((a, h) => a + h.pnl, 0);
  return H.map(h => `${stamp(h.closed).slice(5, 16)} · ${h.name} · ${h.why} · ${usd2(h.pnl)} (${h.r >= 0 ? "+" : ""}${h.r.toFixed(2)} R)`).join("\n") + `\n\nTotale ${ST.hist.length} operazioni: ${usd2(tot)}`;
}
const stratButtons = () => ST.cfg.strats.map(s => [{ text: `${s.on ? "🟢" : "⚪️"} ${s.name}`, callback_data: "tg_" + s.id }]);
const cfgSummary = c => `Rischio ${(c.risk * 100).toLocaleString("it-IT")}% per operazione\n` + c.strats.map(sTxt).join("\n");

async function onMessage(msg) {
  const chatId = msg.chat && msg.chat.id, text = (msg.text || "").trim(); if (!chatId || !text) return;
  const [cmd0, ...args] = text.split(/\s+/), cmd = cmd0.toLowerCase().replace(/@.*/, "");
  if (cmd === "/admin") { if ((args[0] || "").toUpperCase() === CFG.setupCode) { CFG.adminChatId = chatId; saveCfg(); return send("Sei collegato a GoldSilver.\nOra collega il wallet: /collega INDIRIZZO CHIAVE_API_WALLET\n\n" + HELP); } return tg("sendMessage", { chat_id: chatId, text: "Codice non valido." }); }
  if (!CFG.adminChatId || chatId !== CFG.adminChatId) return tg("sendMessage", { chat_id: chatId, text: "Questo è il bot privato di GoldSilver. Per collegarti scrivi /admin CODICE (il codice lo mostra l'installazione sul server)." });
  switch (cmd) {
    case "/start": case "/aiuto": return send(HELP);
    case "/stato": try { await readAccount(); } catch (e) {} return send(statoTxt());
    case "/posizioni": try { await readAccount(); } catch (e) {} return send(posTxt());
    case "/storico": return send(histTxt());
    case "/collega": {
      tg("deleteMessage", { chat_id: chatId, message_id: msg.message_id });
      const addr = (args[0] || "").replace(/\s/g, ""), k0 = (args[1] || "").replace(/\s/g, ""), key = k0.startsWith("0x") ? k0 : "0x" + k0;
      if (!/^0x[0-9a-fA-F]{40}$/.test(addr)) return send("Indirizzo non valido (0x seguito da 40 caratteri). Il messaggio è stato cancellato.");
      if (!/^0x[0-9a-fA-F]{64}$/.test(key)) return send(`Chiave non valida (0x seguito da 64 caratteri, ne hai mandati ${k0.length}). Il messaggio è stato cancellato.`);
      const c = new HLM.Client(CFG.net, addr, key, ["xyz"]);
      if (c.agentAddress().toLowerCase() === addr.toLowerCase()) return send("Questa è la chiave del wallet PRINCIPALE: non usarla. Crea un API wallet su Hyperliquid per il wallet GoldSilver e manda la sua chiave. Il messaggio è stato cancellato.");
      try {
        const v1 = await c.verify("PAXG"), v2 = await c.verify("xyz:SILVER");
        if (!v1.ok || !v2.ok) return send("Verifica non riuscita:\n" + v1.msg + "\n" + v2.msg + "\nControlla di aver autorizzato l'API wallet sul wallet GoldSilver.");
        fs.writeFileSync(KEY_FILE, key, { mode: 0o600 }); CFG.address = addr; saveCfg(); makeClient(); await readAccount().catch(() => {});
        ST.peak = W ? W.acc.equity : 0; saveSt();
        const warn = (!v1.margin ? "\n⚠️ Oro (PAXG): " + v1.msg + " → servono USDC sul conto perp principale." : "") + (!v2.margin ? "\n⚠️ Argento (xyz:SILVER): " + v2.msg + " → servono USDC sul mercato xyz: attiva l'account unificato su Hyperliquid oppure trasferisci USDC al dex xyz (vedi LEGGIMI)." : "");
        slog("Wallet collegato: " + addr);
        return send(`Wallet collegato e verificato. ${W ? "Valore del conto: " + usd2(W.acc.equity) + "." : ""}${warn}\nIl messaggio con la chiave è stato cancellato.\nGoldSilver è SPENTA: controlla con /stato e scrivi /avvia per partire.`);
      } catch (e) { return send("Verifica non riuscita: " + e.message); }
    }
    case "/scollega": try { fs.unlinkSync(KEY_FILE); } catch (e) {} CFG.address = ""; saveCfg(); ST.on = false; saveSt(); makeClient(); return send("Wallet e chiave tolti dal server. GoldSilver è spenta. Le posizioni aperte (se ci sono) restano sull'exchange con i loro stop.");
    case "/avvia": if (!client) return send("Prima collega il wallet: /collega INDIRIZZO CHIAVE"); ST.on = true; ST.since = now(); saveSt(); slog("GoldSilver accesa"); return send("🟢 GoldSilver accesa. Entrerà alla prossima candela con un segnale.\n" + ST.cfg.strats.map(s => (s.on ? "🟢 " : "⚪️ ") + s.name).join("\n"));
    case "/ferma": ST.on = false; saveSt(); slog("GoldSilver spenta"); return send("⚪️ GoldSilver spenta: non apre nuove posizioni. Le posizioni aperte restano con lo stop e il bot continua a gestirle (uscite e trailing). Per chiuderle subito: /chiudi");
    case "/strategie": return send("Strategie (tocca per accendere o spegnere):", stratButtons());
    case "/strategia": { const s = strat((args[0] || "").toLowerCase()); if (!s) return send("Strategia non trovata. Codici: " + ST.cfg.strats.map(x => x.id).join(", ")); const v = (args[1] || "").toLowerCase(); s.on = v === "on" ? true : v === "off" ? false : !s.on; saveSt(); return send(sTxt(s)); }
    case "/applica": {
      let c; try { c = GS.decode(args.join("")); } catch (e) { return send("Codice non valido: " + e.message); }
      ST.pending = c; saveSt();
      return send("Nuova versione dal banco prova:\n\n" + cfgSummary(c) + "\n\nLe posizioni già aperte continuano con le regole con cui sono nate. Applico?", [[{ text: "✅ Applica al bot", callback_data: "ap_ok" }, { text: "❌ No", callback_data: "ap_no" }]]);
    }
    case "/ripristina": if (!ST.cfgPrev) return send("Non c'è una versione precedente."); ST.pending = ST.cfgPrev; saveSt(); return send("Torno alla versione precedente:\n\n" + cfgSummary(ST.cfgPrev) + "\n\nConfermi?", [[{ text: "✅ Ripristina", callback_data: "ap_ok" }, { text: "❌ No", callback_data: "ap_no" }]]);
    case "/migliore": ST.pending = GS.clean(GS.BEST); saveSt(); return send("Torno alla configurazione migliore della ricerca:\n\n" + cfgSummary(ST.pending) + "\n\nConfermi?", [[{ text: "✅ Ripristina", callback_data: "ap_ok" }, { text: "❌ No", callback_data: "ap_no" }]]);
    case "/azzera": try { await readAccount(); } catch (e) {} if (!W) return send("Conto non leggibile ora, riprova."); ST.peak = W.acc.equity; ST.ddAsked = false; saveSt(); return send(`Da ora la discesa si misura da ${usd2(ST.peak)}.`);
    case "/opzione": {
      const k = Object.keys(FUNZ_DEF).find(x => x.toLowerCase() === (args[0] || "").toLowerCase());
      if (!k) return send("Interruttori delle funzioni:\n" + Object.keys(FUNZ_DEF).map(x => `${CFG.funzioni[x] ? "🟢" : "⚪️"} ${x} — ${FUNZ_TXT[x]}`).join("\n") + "\n\nEsempio: /opzione avvisoErrori off");
      const v = (args[1] || "").toLowerCase(); CFG.funzioni[k] = v === "on" ? true : v === "off" ? false : !CFG.funzioni[k]; saveCfg();
      return send(`${CFG.funzioni[k] ? "🟢" : "⚪️"} ${k} — ${FUNZ_TXT[k]}${k === "antiInattivita" ? "\n(vale dal prossimo riavvio del servizio)" : ""}`);
    }
    case "/chiudi": if (!Object.keys(ST.pos).length) return send("Nessuna posizione aperta."); return send("Chiudo subito tutte le posizioni di GoldSilver a mercato?", [[{ text: "✅ Chiudi tutto", callback_data: "cl_ok" }, { text: "❌ No", callback_data: "cl_no" }]]);
    default: return send("Comando non riconosciuto.\n\n" + HELP);
  }
}
async function onCallback(q) {
  const chatId = q.message && q.message.chat && q.message.chat.id, d = q.data || "";
  tg("answerCallbackQuery", { callback_query_id: q.id });
  if (!CFG.adminChatId || chatId !== CFG.adminChatId) return;
  const done = t => tg("editMessageReplyMarkup", { chat_id: chatId, message_id: q.message.message_id, reply_markup: { inline_keyboard: [[{ text: t, callback_data: "x" }]] } });
  if (d.startsWith("tg_")) { const s = strat(d.slice(3)); if (s) { s.on = !s.on; saveSt(); tg("editMessageReplyMarkup", { chat_id: chatId, message_id: q.message.message_id, reply_markup: { inline_keyboard: stratButtons() } }); slog(`${s.name} ${s.on ? "accesa" : "spenta"}`); } return; }
  if (d === "ap_ok") { if (!ST.pending) return done("Già fatto"); const c = ST.pending; ST.cfgPrev = ST.cfg; ST.cfg = Object.assign({}, c, { v: (ST.cfg.v || 1) + 1 }); ST.pending = null; saveSt(); slog("Nuova configurazione applicata, versione " + ST.cfg.v); done("✅ Applicata"); return send("✅ Applicata: versione " + ST.cfg.v + ".\n\n" + cfgSummary(ST.cfg)); }
  if (d === "ap_no") { ST.pending = null; saveSt(); return done("❌ Non applicata"); }
  if (d === "dd_stop") { ST.on = false; saveSt(); slog("GoldSilver spenta dopo l'avviso di discesa"); done("⏹ Fermata"); return send("⏹ GoldSilver spenta: non apre nuove posizioni. Quelle aperte restano con lo stop. Per ripartire: /avvia"); }
  if (d === "dd_go") { done("▶️ Continua"); return send("▶️ GoldSilver continua. Ti richiederò se la discesa torna oltre il 20% dopo un nuovo massimo; /azzera per ripartire da qui."); }
  if (d === "cl_ok") { done("✅ Chiudo"); for (const P of Object.values(ST.pos)) await enqueue(() => doClose(P, "Chiusura manuale")); return send("Fatto.\n" + posTxt()); }
  if (d === "cl_no") return done("❌ Nessuna chiusura");
}
async function tgLoop() {
  for (;;) {
    if (!CFG.telegramToken) { await new Promise(r => setTimeout(r, 5000)); continue; }
    const r = await tg("getUpdates", { offset: CFG.tgOffset, timeout: 25, allowed_updates: ["message", "callback_query"] });
    if (!r || !r.ok) { await new Promise(r2 => setTimeout(r2, 5000)); continue; }
    for (const u of r.result) { CFG.tgOffset = u.update_id + 1; saveCfg();
      try { if (u.message) await onMessage(u.message); else if (u.callback_query) await onCallback(u.callback_query); } catch (e) { slog("errore comando: " + e.message); } }
  }
}

/* ================= resoconto per il PC 1 di Jeriko OS ================= */
// Solo stato e numeri: niente chiave, niente token. Va su Jeriko OS (protetto da password) con un segreto condiviso.
let lastSnap = 0, snapFail = 0;
function snapshot() {
  const eq = W ? W.acc.equity : null;
  return { v: 1, at: now(), on: ST.on, since: ST.since || 0, wallet: CFG.address ? CFG.address.slice(0, 6) + "…" + CFG.address.slice(-4) : "", linked: !!client,
    risk: ST.cfg.risk, ver: ST.cfg.v, strats: ST.cfg.strats.map(s => ({ id: s.id, name: s.name, on: s.on, mkt: s.mkt, fam: E.STRATS[s.key].name, tf: GS.TF_NAMES[s.f] || s.f * 15 + " min", dir: s.dir, p: s.p, ex: exTxt(s.ex) })),
    eq, peak: ST.peak || eq, dd: eq && ST.peak ? 1 - eq / ST.peak : 0, avail: W ? W.acc.available : null, byDex: W ? W.acc.byDex : null,
    pos: Object.values(ST.pos).map(P => ({ name: P.name, coin: P.coin, side: P.side, size: P.size, entry: P.entry, sl: P.sl, stopOk: !!P.slOid, tp: P.tp || 0, opened: P.opened, bars: P.bars, mid: W ? parseFloat(W.mids[P.coin]) || 0 : 0 })),
    hist: ST.hist.slice(-40).map(h => ({ name: h.name, side: h.side, entry: h.entry, exit: h.exit, opened: h.opened, closed: h.closed, why: h.why, pnl: h.pnl, r: h.r })),
    totPnl: ST.hist.reduce((a, h) => a + h.pnl, 0), nTrades: ST.hist.length,
    data: Object.fromEntries(MKTS.map(m => [m, { src: MK[m].src, last: MK[m].rows.length ? MK[m].rows[MK[m].rows.length - 1][0] + BAR : 0 }])), growthOff: ST.growthAlert,
    funzioni: CFG.funzioni, errors: ERR.alerted ? (ERR.lastMsg || "errore") : "" };
}
async function sendSnapshot() {
  if (!CFG.funzioni.resocontoJeriko || !CFG.jerikoUrl || !CFG.jerikoSecret) return;
  try {
    const r = await fetch(CFG.jerikoUrl.replace(/\/$/, "") + "/api/goldsilver", { method: "POST", headers: { "Content-Type": "application/json", "X-GS-Secret": CFG.jerikoSecret }, body: JSON.stringify(snapshot()) });
    if (!r.ok) throw new Error("HTTP " + r.status); if (snapFail >= 5) slog("Resoconto a Jeriko OS di nuovo funzionante"); snapFail = 0;
  } catch (e) { snapFail++; if (snapFail === 5) slog("Resoconto a Jeriko OS non riuscito (" + e.message + "): controlla il segreto GOLDSILVER_SECRET su Cloudflare (node server.js jeriko)"); }
}

/* ================= giro principale ================= */
async function mainLoop() {
  let lastCandles = 0, lastGrowth = 0;
  for (;;) {
    let ok = true;
    try {
      if (client) { await readAccount(); await enqueue(() => protect()); ddCheck(); }
      const q = Math.floor(now() / BAR);
      if (now() - lastCandles > 60000 || Math.floor(lastCandles / BAR) !== q) {
        for (const m of MKTS) { await updateCandles(m); if (MK[m].src) onBars(m); }
        lastCandles = now(); dataCheck();
      }
      if (now() - lastGrowth > 3600000) { lastGrowth = now(); await growthCheck(); }
      if (now() - lastSnap > 60000) { lastSnap = now(); sendSnapshot(); }
    } catch (e) { ok = false; ERR.note(e); slog("errore nel giro: " + e.message); }
    ERR.cycle(ok && !Object.values(MK).some(k => k.fail >= 6 && now() - k.lastOk > 30 * 60000));
    await new Promise(r => setTimeout(r, +process.env.GS_LOOP_MS || 15000));
  }
}
function antiIdle() {
  if (!CFG.funzioni.antiInattivita) return;
  const { Worker } = require("worker_threads"), n = require("os").cpus().length;
  for (let i = 0; i < n; i++) new Worker(`function loop(){const t=Date.now();while(Date.now()-t<25){Math.sqrt(Math.random())}setTimeout(loop,75)}loop()`, { eval: true });
  try { require("os").setPriority(19); } catch (e) {}
  slog("Anti-inattività attivo.");
}
async function main() {
  const arg = process.argv[2];
  if (arg === "token") { CFG.telegramToken = (process.argv[3] || "").trim(); saveCfg(); console.log("Token Telegram salvato."); return; }
  if (arg === "jeriko") { console.log("Segreto per Jeriko OS (Cloudflare → jeriko-os → Settings → Variables and Secrets → Secret, nome GOLDSILVER_SECRET):\n" + CFG.jerikoSecret + "\nIndirizzo di Jeriko OS: " + CFG.jerikoUrl + (process.argv[3] ? "" : "\n(per cambiarlo: node server.js jeriko https://NOME.pages.dev)")); if (process.argv[3]) { CFG.jerikoUrl = process.argv[3].trim(); saveCfg(); console.log("Indirizzo salvato: " + CFG.jerikoUrl); } return; }
  if (arg === "codice") { console.log("Codice: " + CFG.setupCode + "\nScrivi al bot GoldSilver su Telegram: /admin " + CFG.setupCode); return; }
  if (arg === "stato") { console.log(statoTxt()); console.log(posTxt()); return; }
  makeClient();
  slog(`GoldSilver Server avviato · ${ST.on ? "accesa" : "spenta"} · wallet ${CFG.address ? "collegato" : "non collegato"} · Telegram ${CFG.telegramToken ? "configurato" : "NON configurato"}`);
  antiIdle(); tgLoop(); mainLoop();
}
process.on("unhandledRejection", e => slog("errore: " + (e && e.message)));
module.exports = { snapshot, onMessage, onCallback, onBars, protect, doOpen, ST, MK, CFG, W: () => W, setW: w => { W = w; }, setClient: c => { client = c; }, statoTxt, posTxt };
if (require.main === module) main();
